import { createClient } from '@supabase/supabase-js'

// User-provided Supabase credentials
const supabaseUrl = 'https://qnymbecjgeaoxsfphrti.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFueW1iZWNqZ2Vhb3hzZnBocnRpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYwMTczNjEsImV4cCI6MjA3MTU5MzM2MX0.6wAWe5GdKzTOjVa0eUVhDJ4IwczseO9A83uwXlDg0DU'

const supabase = createClient(supabaseUrl, supabaseKey)

async function testDatabaseTables() {
  console.log('🧪 Testing Database Tables')
  console.log('===========================\n')
  
  const tables = [
    'legal_cases',
    'caselaw_cache',
    'judge_patterns',
    'strategic_patterns',
    'legal_scenarios',
    'nash_equilibrium_analysis',
    'precedent_chains'
  ]
  
  for (const table of tables) {
    try {
      const { data, error, count } = await supabase
        .from(table)
        .select('*', { count: 'exact', head: true })
      
      if (error) {
        console.log(`❌ ${table}: Error - ${error.message}`)
      } else {
        console.log(`✅ ${table}: ${count} records`)
      }
    } catch (err) {
      console.log(`❌ ${table}: Connection error - ${err.message}`)
    }
  }
  
  console.log('\n📊 Sample Data Check')
  console.log('=====================')
  
  // Check sample data from caselaw_cache
  try {
    const { data: caselawSample } = await supabase
      .from('caselaw_cache')
      .select('case_title, court, date_decided')
      .limit(3)
    
    if (caselawSample && caselawSample.length > 0) {
      console.log('\n📚 Sample Caselaw Data:')
      caselawSample.forEach((case_, index) => {
        console.log(`${index + 1}. ${case_.case_title} (${case_.court}, ${case_.date_decided})`)
      })
    }
  } catch (err) {
    console.log('❌ Could not fetch sample caselaw data')
  }
  
  // Check sample legal cases
  try {
    const { data: legalCases } = await supabase
      .from('legal_cases')
      .select('case_name, case_type, jurisdiction, case_status')
      .limit(3)
    
    if (legalCases && legalCases.length > 0) {
      console.log('\n⚖️  Sample Legal Cases:')
      legalCases.forEach((case_, index) => {
        console.log(`${index + 1}. ${case_.case_name} (${case_.case_type}, ${case_.jurisdiction}, ${case_.case_status})`)
      })
    }
  } catch (err) {
    console.log('❌ Could not fetch sample legal cases')
  }
  
  console.log('\n✅ Database test completed!')
}

if (import.meta.main) {
  testDatabaseTables().catch(console.error)
}
