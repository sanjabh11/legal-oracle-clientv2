import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Toaster } from 'sonner'

// Layout Components
import Header from './components/layout/Header'
import Sidebar from './components/layout/Sidebar'

// Page Components
import Dashboard from './pages/Dashboard'
import CaseOutcomePrediction from './pages/CaseOutcomePrediction'
import CaselawSearch from './pages/CaselawSearch'
import JudgeBehaviorAnalysis from './pages/JudgeBehaviorAnalysis'
import LegalTrendForecasting from './pages/LegalTrendForecasting'
import StrategyOptimization from './pages/StrategyOptimization'
import SimilarCaseFinder from './pages/SimilarCaseFinder'
import DocumentAnalysis from './pages/DocumentAnalysis'
import MultiPlayerScenarios from './pages/MultiPlayerScenarios'
import NashEquilibrium from './pages/NashEquilibrium'
import CoalitionAnalysis from './pages/CoalitionAnalysis'
import SettlementAnalysis from './pages/SettlementAnalysis'
import NegotiationModeling from './pages/NegotiationModeling'
import StrategicIntelligence from './pages/StrategicIntelligence'

// Context Providers
import { LegalOracleProvider } from './contexts/LegalOracleContext'

function App() {
  return (
    <LegalOracleProvider>
      <Router>
        <div className="min-h-screen bg-slate-50">
          <Header />
          <div className="flex">
            <Sidebar />
            <main className="flex-1 p-6 ml-64">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/predict-outcome" element={<CaseOutcomePrediction />} />
                <Route path="/caselaw-search" element={<CaselawSearch />} />
                <Route path="/judge-analysis" element={<JudgeBehaviorAnalysis />} />
                <Route path="/trend-forecasting" element={<LegalTrendForecasting />} />
                <Route path="/strategy-optimization" element={<StrategyOptimization />} />
                <Route path="/similar-cases" element={<SimilarCaseFinder />} />
                <Route path="/document-analysis" element={<DocumentAnalysis />} />
                <Route path="/multiplayer-scenarios" element={<MultiPlayerScenarios />} />
                <Route path="/nash-equilibrium" element={<NashEquilibrium />} />
                <Route path="/coalition-analysis" element={<CoalitionAnalysis />} />
                <Route path="/settlement-analysis" element={<SettlementAnalysis />} />
                <Route path="/negotiation-modeling" element={<NegotiationModeling />} />
                <Route path="/strategic-intelligence" element={<StrategicIntelligence />} />
              </Routes>
            </main>
          </div>
        </div>
        <Toaster position="top-right" richColors />
      </Router>
    </LegalOracleProvider>
  )
}

export default App
