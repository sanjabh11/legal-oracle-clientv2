import { createClient } from '@supabase/supabase-js'

// User-provided Supabase credentials for qnymbecjgeaoxsfphrti project
const supabaseUrl = 'https://qnymbecjgeaoxsfphrti.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFueW1iZWNqZ2Vhb3hzZnBocnRpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYwMTczNjEsImV4cCI6MjA3MTU5MzM2MX0.6wAWe5GdKzTOjVa0eUVhDJ4IwczseO9A83uwXlDg0DU'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Test database connection
export async function testConnection() {
  try {
    const { data, error } = await supabase
      .from('legal_oracle_cases')
      .select('count')
      .limit(1)
    
    if (error) {
      console.error('Supabase connection error:', error)
      return false
    }
    
    console.log('✅ Supabase connection successful')
    return true
  } catch (err) {
    console.error('Connection failed:', err)
    return false
  }
}

// Database service functions
export const legalOracleDB = {
  // Fetch legal cases
  async getCases() {
    const { data, error } = await supabase
      .from('legal_oracle_cases')
      .select('*')
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data
  },

  // Fetch caselaw data from HuggingFace cache
  async getCaselaw(limit = 10) {
    const { data, error } = await supabase
      .from('legal_oracle_caselaw_cache')
      .select('*')
      .order('fetch_timestamp', { ascending: false })
      .limit(limit)
    
    if (error) throw error
    return data
  },

  // Search caselaw by title or content
  async searchCaselaw(query: string) {
    const { data, error } = await supabase
      .from('legal_oracle_caselaw_cache')
      .select('*')
      .or(`case_title.ilike.%${query}%,case_text.ilike.%${query}%,case_summary.ilike.%${query}%`)
      .order('fetch_timestamp', { ascending: false })
      .limit(20)
    
    if (error) throw error
    return data
  },

  // Fetch judge patterns
  async getJudgePatterns() {
    const { data, error } = await supabase
      .from('legal_oracle_judge_patterns')
      .select('*')
      .order('cases_decided', { ascending: false })
    
    if (error) throw error
    return data
  },

  // Search judges by name or court
  async searchJudges(query: string) {
    const { data, error } = await supabase
      .from('legal_oracle_judge_patterns')
      .select('*')
      .or(`judge_name.ilike.%${query}%,court.ilike.%${query}%`)
      .order('cases_decided', { ascending: false })
    
    if (error) throw error
    return data
  },

  // Fetch strategic patterns for game theory
  async getStrategicPatterns() {
    const { data, error } = await supabase
      .from('legal_oracle_strategic_patterns')
      .select('*')
      .order('success_probability', { ascending: false })
    
    if (error) throw error
    return data
  },

  // Fetch legal scenarios
  async getLegalScenarios() {
    const { data, error } = await supabase
      .from('legal_oracle_scenarios')
      .select('*')
      .order('precedent_impact_score', { ascending: false })
    
    if (error) throw error
    return data
  },

  // Get scenario by ID
  async getScenario(id: number) {
    const { data, error } = await supabase
      .from('legal_oracle_scenarios')
      .select('*')
      .eq('id', id)
      .maybeSingle()
    
    if (error) throw error
    return data
  },

  // Create Nash equilibrium analysis
  async createNashAnalysis(analysis: any) {
    const { data, error } = await supabase
      .from('legal_oracle_nash_equilibrium')
      .insert(analysis)
      .select()
      .maybeSingle()
    
    if (error) throw error
    return data
  },

  // Get Nash equilibrium analysis for scenario
  async getNashAnalysis(scenarioId: number) {
    const { data, error } = await supabase
      .from('legal_oracle_nash_equilibrium')
      .select('*')
      .eq('scenario_id', scenarioId)
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data
  }
}
