import React, { useState } from 'react'
import { useLegalOracle } from '../contexts/LegalOracleContext'
import { Shield, Target, Brain, TrendingUp, DollarSign, Clock, AlertTriangle } from 'lucide-react'
import { toast } from 'sonner'

const StrategyOptimization: React.FC = () => {
  const { cases, analysisResults, optimizeStrategy } = useLegalOracle()
  const [selectedCase, setSelectedCase] = useState<any>(null)
  const [customStrategy, setCustomStrategy] = useState({
    case_name: '',
    case_type: 'civil',
    jurisdiction: 'federal',
    summary: '',
    objectives: '',
    constraints: '',
    timeline: '',
    budget: ''
  })
  const [useCustomCase, setUseCustomCase] = useState(false)
  const [isOptimizing, setIsOptimizing] = useState(false)

  const handleOptimizeStrategy = async () => {
    const caseData = useCustomCase ? customStrategy : selectedCase
    
    if (!caseData || (!caseData.summary && !caseData.case_description)) {
      toast.error('Please provide case details for strategy optimization')
      return
    }

    setIsOptimizing(true)
    try {
      await optimizeStrategy(caseData)
      toast.success('Legal strategy optimization completed')
    } catch (error) {
      console.error('Strategy optimization failed:', error)
    } finally {
      setIsOptimizing(false)
    }
  }

  const strategy = analysisResults.strategy_optimization

  const getSuccessProbabilityColor = (probability: number) => {
    if (probability >= 0.75) return 'text-green-600 bg-green-50'
    if (probability >= 0.5) return 'text-yellow-600 bg-yellow-50'
    return 'text-red-600 bg-red-50'
  }

  const getRiskLevelColor = (level: string) => {
    if (level?.toLowerCase() === 'low') return 'text-green-600 bg-green-50'
    if (level?.toLowerCase() === 'medium') return 'text-yellow-600 bg-yellow-50'
    return 'text-red-600 bg-red-50'
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900 flex items-center">
          <Shield className="h-8 w-8 text-blue-600 mr-3" />
          Legal Strategy Optimization
        </h1>
        <p className="mt-2 text-lg text-slate-600">
          AI-powered strategic planning and optimization for legal cases
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <div className="space-y-6">
          {/* Case Selection */}
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-medium text-slate-900 mb-4">Select Case for Strategy Optimization</h3>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <input
                  type="radio"
                  id="existing-strategy-case"
                  name="strategy-case-source"
                  checked={!useCustomCase}
                  onChange={() => setUseCustomCase(false)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300"
                />
                <label htmlFor="existing-strategy-case" className="text-sm font-medium text-slate-700">
                  Use Existing Legal Case
                </label>
              </div>
              
              {!useCustomCase && (
                <select
                  value={selectedCase?.id || ''}
                  onChange={(e) => {
                    const case_ = cases.find(c => c.id === e.target.value)
                    setSelectedCase(case_)
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select a legal case...</option>
                  {cases.map((case_) => (
                    <option key={case_.id} value={case_.id}>
                      {case_.case_name} ({case_.case_type} - {case_.jurisdiction})
                    </option>
                  ))}
                </select>
              )}
              
              <div className="flex items-center space-x-3">
                <input
                  type="radio"
                  id="custom-strategy-case"
                  name="strategy-case-source"
                  checked={useCustomCase}
                  onChange={() => setUseCustomCase(true)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300"
                />
                <label htmlFor="custom-strategy-case" className="text-sm font-medium text-slate-700">
                  Enter Custom Case for Strategy Planning
                </label>
              </div>
            </div>
          </div>

          {/* Custom Strategy Input */}
          {useCustomCase && (
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
              <h3 className="text-lg font-medium text-slate-900 mb-4">Strategic Planning Details</h3>
              
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Case Name</label>
                    <input
                      type="text"
                      value={customStrategy.case_name}
                      onChange={(e) => setCustomStrategy(prev => ({ ...prev, case_name: e.target.value }))}
                      className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Enter case name..."
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Case Type</label>
                    <select
                      value={customStrategy.case_type}
                      onChange={(e) => setCustomStrategy(prev => ({ ...prev, case_type: e.target.value }))}
                      className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="civil">Civil</option>
                      <option value="criminal">Criminal</option>
                      <option value="corporate">Corporate</option>
                      <option value="ip">Intellectual Property</option>
                      <option value="employment">Employment</option>
                      <option value="regulatory">Regulatory</option>
                    </select>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700">Case Summary</label>
                  <textarea
                    value={customStrategy.summary}
                    onChange={(e) => setCustomStrategy(prev => ({ ...prev, summary: e.target.value }))}
                    rows={3}
                    className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Describe the case details and key issues..."
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700">Strategic Objectives</label>
                  <textarea
                    value={customStrategy.objectives}
                    onChange={(e) => setCustomStrategy(prev => ({ ...prev, objectives: e.target.value }))}
                    rows={2}
                    className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="What are the primary objectives and desired outcomes?"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Budget Constraints</label>
                    <input
                      type="text"
                      value={customStrategy.budget}
                      onChange={(e) => setCustomStrategy(prev => ({ ...prev, budget: e.target.value }))}
                      className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      placeholder="e.g., $50,000 - $150,000"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Timeline</label>
                    <input
                      type="text"
                      value={customStrategy.timeline}
                      onChange={(e) => setCustomStrategy(prev => ({ ...prev, timeline: e.target.value }))}
                      className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      placeholder="e.g., 12-18 months"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Selected Case Display */}
          {!useCustomCase && selectedCase && (
            <div className="bg-slate-50 rounded-lg border border-slate-200 p-6">
              <h3 className="text-lg font-medium text-slate-900 mb-3">{selectedCase.case_name}</h3>
              <div className="space-y-2 text-sm">
                <p><span className="font-medium">Type:</span> {selectedCase.case_type}</p>
                <p><span className="font-medium">Jurisdiction:</span> {selectedCase.jurisdiction}</p>
                <p><span className="font-medium">Summary:</span> {selectedCase.summary}</p>
              </div>
            </div>
          )}

          {/* Optimization Button */}
          <button
            onClick={handleOptimizeStrategy}
            disabled={isOptimizing || (!selectedCase && !useCustomCase) || (useCustomCase && !customStrategy.summary)}
            className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 disabled:bg-slate-400 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isOptimizing ? (
              <>
                <Brain className="animate-pulse h-5 w-5 mr-2" />
                Optimizing Strategy...
              </>
            ) : (
              <>
                <Target className="h-5 w-5 mr-2" />
                Optimize Legal Strategy
              </>
            )}
          </button>
        </div>

        {/* Results Section */}
        <div className="space-y-6">
          {strategy ? (
            <>
              {/* Primary Strategy */}
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
                <div className="flex items-center mb-4">
                  <Target className="h-6 w-6 text-green-600 mr-2" />
                  <h3 className="text-lg font-medium text-slate-900">Recommended Strategy</h3>
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-blue-900 font-medium">{strategy.primary_strategy}</p>
                </div>
              </div>

              {/* Key Metrics */}
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
                <h3 className="text-lg font-medium text-slate-900 mb-4">Strategic Analysis</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className={`p-4 rounded-lg ${getSuccessProbabilityColor(strategy.settlement_probability || 0.65)}`}>
                    <div className="text-2xl font-bold mb-1">
                      {Math.round((strategy.settlement_probability || 0.65) * 100)}%
                    </div>
                    <div className="text-sm font-medium">Settlement Probability</div>
                  </div>
                  
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-slate-900 mb-1">
                      {strategy.timeline_prediction || '12-18 months'}
                    </div>
                    <div className="text-sm font-medium text-slate-600">Expected Timeline</div>
                  </div>
                </div>
              </div>

              {/* Financial Analysis */}
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
                <div className="flex items-center mb-4">
                  <DollarSign className="h-6 w-6 text-green-600 mr-2" />
                  <h3 className="text-lg font-medium text-slate-900">Financial Projections</h3>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-600">Estimated Legal Costs</span>
                    <span className="font-medium text-slate-900">{strategy.estimated_costs}</span>
                  </div>
                </div>
              </div>

              {/* Alternative Approaches */}
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
                <h3 className="text-lg font-medium text-slate-900 mb-4">Alternative Approaches</h3>
                
                <div className="space-y-3">
                  {strategy.alternative_approaches?.map((approach: string, index: number) => (
                    <div key={index} className="flex items-center p-3 bg-slate-50 rounded-lg">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                      <span className="text-slate-700">{approach}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Success Factors */}
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
                <div className="flex items-center mb-4">
                  <TrendingUp className="h-6 w-6 text-blue-600 mr-2" />
                  <h3 className="text-lg font-medium text-slate-900">Success Factors</h3>
                </div>
                
                <ul className="list-disc list-inside space-y-2 text-sm text-slate-700">
                  {strategy.success_factors?.map((factor: string, index: number) => (
                    <li key={index}>{factor}</li>
                  ))}
                </ul>
              </div>

              {/* Risk Mitigation */}
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
                <div className="flex items-center mb-4">
                  <AlertTriangle className="h-6 w-6 text-orange-600 mr-2" />
                  <h3 className="text-lg font-medium text-slate-900">Risk Mitigation</h3>
                </div>
                
                <ul className="list-disc list-inside space-y-2 text-sm text-slate-700">
                  {strategy.risk_mitigation?.map((risk: string, index: number) => (
                    <li key={index}>{risk}</li>
                  ))}
                </ul>
              </div>
            </>
          ) : (
            <div className="bg-slate-50 rounded-lg border border-slate-200 p-8 text-center">
              <Shield className="h-12 w-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-500 mb-2">No Strategy Generated</h3>
              <p className="text-slate-400">
                Select a case and click "Optimize Legal Strategy" to receive AI-powered strategic recommendations
              </p>
            </div>
          )}
          
          {/* AI Information */}
          <div className="bg-green-50 rounded-lg border border-green-200 p-6">
            <div className="flex items-start">
              <Brain className="h-6 w-6 text-green-600 mt-1" />
              <div className="ml-3">
                <h3 className="text-sm font-medium text-green-900">Strategic AI Analysis</h3>
                <p className="mt-1 text-sm text-green-700">
                  Our AI system analyzes case details, precedents, and strategic variables to generate 
                  optimized legal strategies. The recommendations consider success probability, cost efficiency, 
                  timeline constraints, and risk factors to provide comprehensive strategic guidance.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default StrategyOptimization
