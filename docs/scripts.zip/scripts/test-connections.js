const supabaseUrl = 'https://qnymbecjgeaoxsfphrti.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFueW1iZWNqZ2Vhb3hzZnBocnRpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYwMTczNjEsImV4cCI6MjA3MTU5MzM2MX0.6wAWe5GdKzTOjVa0eUVhDJ4IwczseO9A83uwXlDg0DU'
const huggingFaceToken = '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'

// Simple test connection using fetch API
async function testConnection() {
  console.log('Testing Supabase connection...')
  
  try {
    const response = await fetch(`${supabaseUrl}/rest/v1/`, {
      headers: {
        'apikey': supabaseKey,
        'Authorization': `Bearer ${supabaseKey}`,
        'Content-Type': 'application/json'
      }
    })
    
    console.log('Response status:', response.status)
    console.log('Response headers:', Object.fromEntries(response.headers.entries()))
    
    if (response.status === 200 || response.status === 404) {
      console.log('✅ Supabase connection successful')
      return true
    } else {
      console.log('❌ Unexpected response status:', response.status)
      return false
    }
  } catch (error) {
    console.error('❌ Connection error:', error)
    return false
  }
}

// Test HuggingFace API
async function testHuggingFace() {
  console.log('\nTesting HuggingFace API...')
  
  try {
    const response = await fetch(
      'https://datasets-server.huggingface.co/info?dataset=TeraflopAI%2FCaselaw-Access-Project',
      {
        headers: {
          'Authorization': `Bearer ${huggingFaceToken}`,
          'Content-Type': 'application/json'
        }
      }
    )
    
    console.log('HuggingFace response status:', response.status)
    
    if (response.ok) {
      const data = await response.json()
      console.log('✅ HuggingFace API accessible')
      console.log('Dataset info:', JSON.stringify(data, null, 2))
      return true
    } else {
      const errorText = await response.text()
      console.log('❌ HuggingFace API error:', response.status, errorText)
      return false
    }
  } catch (error) {
    console.error('❌ HuggingFace API error:', error)
    return false
  }
}

// Run tests
async function runTests() {
  console.log('🧪 Testing API Connections')
  console.log('==========================\n')
  
  const supabaseOk = await testConnection()
  const hfOk = await testHuggingFace()
  
  console.log('\n📋 Test Summary:')
  console.log(`Supabase: ${supabaseOk ? '✅' : '❌'}`)
  console.log(`HuggingFace: ${hfOk ? '✅' : '❌'}`)
  
  if (supabaseOk && hfOk) {
    console.log('\n🎉 All connections working! Ready to proceed with database setup.')
  } else {
    console.log('\n⚠️  Some connections failed. Please check credentials.')
  }
}

runTests().catch(console.error)