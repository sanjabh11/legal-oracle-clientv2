import React, { useState } from 'react'
import { useLegalOracle } from '../contexts/LegalOracleContext'
import { TrendingUp, Calendar, BarChart3, Activity, LineChart, Brain } from 'lucide-react'
import { huggingFaceAI } from '../lib/huggingface'
import { toast } from 'sonner'

const LegalTrendForecasting: React.FC = () => {
  const { cases, caselaw, loading } = useLegalOracle()
  const [selectedTimeframe, setSelectedTimeframe] = useState('12_months')
  const [selectedLegalArea, setSelectedLegalArea] = useState('all')
  const [trends, setTrends] = useState<any>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const timeframes = {
    '6_months': '6 Months',
    '12_months': '12 Months', 
    '2_years': '2 Years',
    '5_years': '5 Years'
  }

  const legalAreas = {
    'all': 'All Legal Areas',
    'civil': 'Civil Law',
    'criminal': 'Criminal Law',
    'corporate': 'Corporate Law',
    'ip': 'Intellectual Property',
    'employment': 'Employment Law',
    'environmental': 'Environmental Law',
    'regulatory': 'Regulatory Law'
  }

  const handleForecastTrends = async () => {
    setIsAnalyzing(true)
    try {
      // Combine cases and caselaw data for analysis
      const historicalData = [...cases, ...caselaw].map(item => ({
        date: item.date_decided || item.filed_date || item.created_at,
        type: item.case_type || 'general',
        jurisdiction: item.jurisdiction || 'federal',
        outcome: item.outcome || 'decided',
        legal_issues: item.legal_issues || item.legal_topics || []
      }))

      const forecast = await huggingFaceAI.forecastLegalTrends(
        historicalData,
        timeframes[selectedTimeframe as keyof typeof timeframes]
      )
      
      setTrends(forecast)
      toast.success('Legal trend forecasting completed')
    } catch (error) {
      console.error('Trend forecasting failed:', error)
      toast.error('Failed to generate trend forecast')
    } finally {
      setIsAnalyzing(false)
    }
  }

  const getTrendColor = (trend: string) => {
    if (trend.toLowerCase().includes('increase') || trend.toLowerCase().includes('growth')) {
      return 'text-green-600 bg-green-50'
    }
    if (trend.toLowerCase().includes('decrease') || trend.toLowerCase().includes('decline')) {
      return 'text-red-600 bg-red-50'
    }
    return 'text-blue-600 bg-blue-50'
  }

  const historicalStats = {
    total_cases: cases.length + caselaw.length,
    civil_cases: [...cases, ...caselaw].filter(c => c.case_type === 'civil' || c.legal_topics?.includes('civil')).length,
    federal_jurisdiction: [...cases, ...caselaw].filter(c => c.jurisdiction === 'federal' || c.jurisdiction === 'Federal').length,
    recent_cases: [...cases, ...caselaw].filter(c => {
      const date = new Date(c.date_decided || c.filed_date || c.created_at)
      const oneYearAgo = new Date()
      oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1)
      return date > oneYearAgo
    }).length
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900 flex items-center">
          <TrendingUp className="h-8 w-8 text-blue-600 mr-3" />
          Legal Trend Forecasting
        </h1>
        <p className="mt-2 text-lg text-slate-600">
          Predict future legal trends based on historical data and AI analysis
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls */}
        <div className="lg:col-span-1 space-y-6">
          {/* Forecast Settings */}
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-medium text-slate-900 mb-4">Forecast Parameters</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Time Horizon</label>
                <select
                  value={selectedTimeframe}
                  onChange={(e) => setSelectedTimeframe(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  {Object.entries(timeframes).map(([key, label]) => (
                    <option key={key} value={key}>{label}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Legal Area Focus</label>
                <select
                  value={selectedLegalArea}
                  onChange={(e) => setSelectedLegalArea(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  {Object.entries(legalAreas).map(([key, label]) => (
                    <option key={key} value={key}>{label}</option>
                  ))}
                </select>
              </div>
              
              <button
                onClick={handleForecastTrends}
                disabled={isAnalyzing}
                className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 disabled:bg-slate-400 flex items-center justify-center"
              >
                {isAnalyzing ? (
                  <>
                    <Activity className="animate-pulse h-5 w-5 mr-2" />
                    Analyzing Trends...
                  </>
                ) : (
                  <>
                    <LineChart className="h-5 w-5 mr-2" />
                    Generate Forecast
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Historical Overview */}
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-medium text-slate-900 mb-4">Historical Data Overview</h3>
            
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Total Cases</span>
                <span className="font-medium text-slate-900">{historicalStats.total_cases}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Civil Cases</span>
                <span className="font-medium text-slate-900">{historicalStats.civil_cases}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Federal Jurisdiction</span>
                <span className="font-medium text-slate-900">{historicalStats.federal_jurisdiction}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Recent Cases (1 Year)</span>
                <span className="font-medium text-slate-900">{historicalStats.recent_cases}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="lg:col-span-2 space-y-6">
          {trends ? (
            <>
              {/* Forecast Summary */}
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
                <div className="flex items-center mb-4">
                  <TrendingUp className="h-6 w-6 text-green-600 mr-2" />
                  <h3 className="text-lg font-medium text-slate-900">
                    Forecast for {timeframes[selectedTimeframe as keyof typeof timeframes]}
                  </h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="text-sm text-blue-600 font-medium">Confidence Level</div>
                    <div className="text-2xl font-bold text-blue-900">
                      {Math.round((trends.confidence_level || 0.7) * 100)}%
                    </div>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <div className="text-sm text-green-600 font-medium">Timeframe</div>
                    <div className="text-2xl font-bold text-green-900">
                      {trends.timeframe}
                    </div>
                  </div>
                </div>
              </div>

              {/* Predicted Trends */}
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
                <h3 className="text-lg font-medium text-slate-900 mb-4">Predicted Trends</h3>
                
                <div className="space-y-3">
                  {trends.predicted_trends?.map((trend: string, index: number) => (
                    <div key={index} className={`p-3 rounded-lg ${getTrendColor(trend)}`}>
                      <div className="flex items-center">
                        <BarChart3 className="h-5 w-5 mr-3" />
                        <span className="font-medium">{trend}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Supporting Factors */}
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
                <h3 className="text-lg font-medium text-slate-900 mb-4">Supporting Factors</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-sm font-medium text-slate-700 mb-2">Trend Drivers</h4>
                    <ul className="list-disc list-inside space-y-1 text-sm text-slate-600">
                      {trends.supporting_factors?.map((factor: string, index: number) => (
                        <li key={index}>{factor}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-slate-700 mb-2">Potential Disruptions</h4>
                    <ul className="list-disc list-inside space-y-1 text-sm text-slate-600">
                      {trends.potential_disruptions?.map((disruption: string, index: number) => (
                        <li key={index}>{disruption}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Recommendations */}
              <div className="bg-slate-50 rounded-lg border border-slate-200 p-6">
                <h3 className="text-lg font-medium text-slate-900 mb-4">Strategic Recommendations</h3>
                <div className="bg-white p-4 rounded-lg">
                  <p className="text-slate-700">{trends.recommendation}</p>
                </div>
              </div>
            </>
          ) : (
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-12 text-center">
              {isAnalyzing ? (
                <>
                  <Activity className="animate-pulse h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-slate-500 mb-2">Analyzing Legal Trends...</h3>
                  <p className="text-slate-400">
                    Processing historical data and generating forecasts
                  </p>
                </>
              ) : (
                <>
                  <Calendar className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-slate-500 mb-2">No Forecast Generated</h3>
                  <p className="text-slate-400">
                    Configure your parameters and click "Generate Forecast" to see trend predictions
                  </p>
                </>
              )}
            </div>
          )}
          
          {/* AI Information */}
          <div className="bg-orange-50 rounded-lg border border-orange-200 p-6">
            <div className="flex items-start">
              <Brain className="h-6 w-6 text-orange-600 mt-1" />
              <div className="ml-3">
                <h3 className="text-sm font-medium text-orange-900">Predictive Legal Analytics</h3>
                <p className="mt-1 text-sm text-orange-700">
                  This forecasting system analyzes historical legal patterns, case outcomes, and regulatory changes 
                  to predict future trends. The AI model considers multiple factors including precedent evolution, 
                  legislative patterns, and judicial behavioral shifts to generate strategic insights for legal planning.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default LegalTrendForecasting
