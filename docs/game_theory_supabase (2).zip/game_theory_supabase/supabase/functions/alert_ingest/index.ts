// alert_ingest/index.ts
// Supabase Edge Function (Deno + supabase-js) — posts ingest alerts to Slack

// deno-lint-ignore-file no-explicit-any
import { serve } from "https://deno.land/std@0.192.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const SLACK_WEBHOOK = "https://hooks.slack.com/services/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";
const ALERT_THRESHOLD_SECONDS = parseInt(Deno.env.get("ALERT_THRESHOLD_SECONDS") || "300", 10);
const ALERT_REPEAT_SECONDS = parseInt(Deno.env.get("ALERT_REPEAT_SECONDS") || "1800", 10);

const sb = createClient(SUPABASE_URL, SERVICE_KEY, { auth: { persistSession: false } });

type IngestRow = {
  id?: number;
  source: string;
  last_success_at?: string | null;
  last_error_at?: string | null;
  last_error?: string | null;
  last_row_ts?: string | null;
  updated_at?: string | null;
};

function secsSince(ts?: string | null) {
  if (!ts) return Number.POSITIVE_INFINITY;
  const then = new Date(ts).getTime();
  return (Date.now() - then) / 1000;
}

async function sendSlack(text: string, blocks?: any) {
  const payload: any = { text };
  if (blocks) payload.blocks = blocks;
  const resp = await fetch(SLACK_WEBHOOK, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!resp.ok) {
    const body = await resp.text().catch(() => "");
    throw new Error(`Slack post failed ${resp.status}: ${body}`);
  }
  return true;
}

async function getLatestIngestRows(): Promise<IngestRow[]> {
  // fetch recent ingest_status entries and reduce to latest per source
  const { data, error } = await sb
    .from("ingest_status")
    .select("id, source, last_success_at, last_error_at, last_error, last_row_ts, updated_at")
    .order("updated_at", { ascending: false })
    .limit(200);

  if (error) throw error;
  const map = new Map<string, IngestRow>();
  (data || []).forEach((r: any) => {
    if (!map.has(r.source)) map.set(r.source, r as IngestRow);
  });
  return Array.from(map.values());
}

async function lastAlertExists(source: string, alert_type: string) {
  const { data, error } = await sb
    .from("alerts_sent")
    .select("last_alert_at")
    .eq("source", source)
    .eq("alert_type", alert_type)
    .limit(1)
    .maybeSingle();

  if (error) throw error;
  if (!data) return false;
  const last = data.last_alert_at;
  if (!last) return false;
  const age = secsSince(last);
  return age < ALERT_REPEAT_SECONDS;
}

async function upsertAlert(source: string, alert_type: string, details: any) {
  // try upsert: update existing or insert new
  const now = new Date().toISOString();
  const { error } = await sb
    .from("alerts_sent")
    .upsert(
      { source, alert_type, last_alert_at: now, details, created_at: now },
      { onConflict: ["source", "alert_type"] }
    );
  if (error) console.error("upsertAlert error:", error);
}

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    // optional quick status route
    const url = new URL(req.url);
    if (url.searchParams.get("mode") === "status") {
      return new Response(JSON.stringify({ ok: true, now: new Date().toISOString() }), { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }

    const rows = await getLatestIngestRows();
    if (!rows.length) {
      // Send a test notification if no ingest rows exist
      await sendSlack("🔔 Alert system operational - no ingest_status data found. This is expected for initial setup.");
      return new Response(JSON.stringify({ ok: true, msg: "no ingest_status rows - sent test notification" }), { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }

    const alertsSent: any[] = [];
    // Evaluate each source
    for (const row of rows) {
      const source = row.source;
      const secsSinceSuccess = secsSince(row.last_success_at);
      const hasRecentError = row.last_error_at && secsSince(row.last_error_at) < ALERT_THRESHOLD_SECONDS;

      // Condition 1: stale feed (no success within threshold)
      if (!row.last_success_at || secsSinceSuccess > ALERT_THRESHOLD_SECONDS) {
        const skip = await lastAlertExists(source, "stale");
        if (!skip) {
          const text = `:warning: *Ingest stale* — source *${source}* has no successful ingest within ${ALERT_THRESHOLD_SECONDS}s.\n• last_success_at: ${row.last_success_at ?? "none"}\n• last_row_ts: ${row.last_row_ts ?? "none"}`;
          const blocks = [
            { type: "section", text: { type: "mrkdwn", text } },
            { type: "context", elements: [{ type: "mrkdwn", text: `ingest_status updated: ${row.updated_at ?? "unknown"}` }] }
          ];
          try {
            await sendSlack(text, blocks);
            await upsertAlert(source, "stale", { row });
            alertsSent.push({ source, alert_type: "stale" });
          } catch (e) {
            console.error("Slack send error (stale):", e);
          }
        }
      }

      // Condition 2: active error recently logged
      if (row.last_error_at && secsSince(row.last_error_at) < ALERT_THRESHOLD_SECONDS) {
        const skip = await lastAlertExists(source, "error");
        if (!skip) {
          const text = `:rotating_light: *Ingest error* — source *${source}* reported an error recently.\n• last_error_at: ${row.last_error_at}\n• last_error: ${row.last_error}`;
          const blocks = [
            { type: "section", text: { type: "mrkdwn", text } },
            { type: "context", elements: [{ type: "mrkdwn", text: `ingest_status updated: ${row.updated_at ?? "unknown"}` }] }
          ];
          try {
            await sendSlack(text, blocks);
            await upsertAlert(source, "error", { row });
            alertsSent.push({ source, alert_type: "error" });
          } catch (e) {
            console.error("Slack send error (error):", e);
          }
        }
      }

      // Condition 3: recovered (optional) — if we recently had an alert and now success is fresh
      if (row.last_success_at && secsSince(row.last_success_at) < ALERT_THRESHOLD_SECONDS) {
        // check if a 'stale' alert exists and last_alert_at > last_success_at (meaning previously alerted)
        const { data: prevAlert } = await sb
          .from("alerts_sent")
          .select("last_alert_at")
          .eq("source", source)
          .eq("alert_type", "stale")
          .limit(1)
          .maybeSingle();

        if (prevAlert && prevAlert.last_alert_at) {
          const alertAge = secsSince(prevAlert.last_alert_at);
          // only send recovered once then update
          if (alertAge < 86400) {
            const skip = await lastAlertExists(source, "recovered");
            if (!skip) {
              const text = `:white_check_mark: *Ingest recovered* — source *${source}* ingestion resumed.\n• last_success_at: ${row.last_success_at}\n• last_row_ts: ${row.last_row_ts ?? "none"}`;
              try {
                await sendSlack(text);
                await upsertAlert(source, "recovered", { row });
                alertsSent.push({ source, alert_type: "recovered" });
              } catch (e) {
                console.error("Slack send error (recovered):", e);
              }
            }
          }
        }
      }
    }

    return new Response(JSON.stringify({ ok: true, checked: rows.length, alerts: alertsSent }), { 
      status: 200, 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
    });
  } catch (err) {
    console.error("alert_ingest error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err) }), { 
      status: 500, 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
    });
  }
});