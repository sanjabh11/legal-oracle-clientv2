// Simple HuggingFace Data Fetcher and SQL Generator
const CONFIG = {
  HUGGINGFACE_TOKEN: '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',
  BATCH_SIZE: 20
};

async function fetchHuggingFaceBatch(offset = 0) {
  const url = `https://datasets-server.huggingface.co/rows?dataset=TeraflopAI%2FCaselaw-Access-Project&config=default&split=train&offset=${offset}&length=${CONFIG.BATCH_SIZE}`;
  
  console.log(`🔄 Fetching batch from HuggingFace: offset=${offset}`);
  
  try {
    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${CONFIG.HUGGINGFACE_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      throw new Error(`HuggingFace API error: ${response.status}`);
    }
    
    const data = await response.json();
    const cases = data.rows || [];
    
    console.log(`✅ Fetched ${cases.length} cases`);
    return cases;
  } catch (error) {
    console.log(`❌ Error: ${error.message}`);
    return [];
  }
}

function generateSQLInserts(cases, batchNum) {
  if (!cases || cases.length === 0) return '';
  
  const legalCaseValues = [];
  const caselawValues = [];
  
  for (let i = 0; i < cases.length; i++) {
    const row = cases[i].row || cases[i];
    const caseText = row.text || '';
    const caseId = `hf_${batchNum}_${i}_${Date.now()}`;
    const firstLine = caseText.split('\n')[0] || '';
    
    // Clean and escape text for SQL
    const cleanText = (text) => {
      if (!text) return '';
      return text.replace(/'/g, "''").replace(/\\/g, "\\\\").substring(0, 1000);
    };
    
    const caseName = cleanText(firstLine) || `Legal Case from Dataset ${batchNum}-${i}`;
    const summary = cleanText(caseText) || 'Legal case from Caselaw Access Project';
    
    // Legal cases insert
    legalCaseValues.push(`(
      '${caseName}',
      'CAP-${caseId}',
      'civil',
      'federal',
      'District Court',
      '2020-01-01',
      'closed',
      '${summary}',
      ARRAY['civil procedure']::TEXT[],
      'Decided',
      0.75,
      1,
      '{"primary_issues": ["civil law"], "applicable_law": "Federal", "key_precedents": []}'::jsonb
    )`);
    
    // Caselaw cache insert
    caselawValues.push(`(
      '${caseId}',
      'TeraflopAI/Caselaw-Access-Project',
      '${caseName}',
      'Federal Court',
      '2020-01-01',
      'federal',
      '${cleanText(caseText.substring(0, 2000))}',
      '${cleanText(caseText.substring(0, 500))}',
      ARRAY[]::TEXT[],
      ARRAY[]::TEXT[],
      'Decided',
      ARRAY['civil law']::TEXT[],
      NOW(),
      NOW()
    )`);
  }
  
  let sql = '';
  
  if (legalCaseValues.length > 0) {
    sql += `INSERT INTO legal_cases (case_name, case_number, case_type, jurisdiction, court_level, filed_date, case_status, summary, legal_issues, outcome, precedent_value, citation_count, legal_principles) VALUES\n${legalCaseValues.join(',\n')};\n\n`;
  }
  
  if (caselawValues.length > 0) {
    sql += `INSERT INTO legal_oracle_caselaw_cache (case_id, dataset_source, case_title, court, date_decided, jurisdiction, case_text, case_summary, legal_citations, judges, outcome, legal_topics, fetch_timestamp, last_accessed) VALUES\n${caselawValues.join(',\n')} ON CONFLICT (case_id) DO NOTHING;\n\n`;
  }
  
  return sql;
}

async function populateBatch(batchNum, offset) {
  console.log(`\n📦 Processing batch ${batchNum}`);
  
  const cases = await fetchHuggingFaceBatch(offset);
  if (cases.length === 0) {
    return null;
  }
  
  const sql = generateSQLInserts(cases, batchNum);
  
  // Write to file
  const fs = require('fs');
  const filename = `sql_batches/batch_${batchNum}.sql`;
  
  try {
    fs.writeFileSync(filename, sql);
    console.log(`✅ Generated SQL file: ${filename} (${cases.length} cases)`);
    return { filename, count: cases.length };
  } catch (error) {
    console.log(`❌ Error writing SQL file: ${error.message}`);
    return null;
  }
}

async function main() {
  console.log('🚀 Legal Oracle Batch SQL Generator');
  console.log('====================================\n');
  
  const totalBatches = 20; // Process 20 batches = ~400 cases to start
  let totalCases = 0;
  let successfulBatches = 0;
  
  for (let i = 0; i < totalBatches; i++) {
    const result = await populateBatch(i + 1, i * CONFIG.BATCH_SIZE);
    
    if (result) {
      totalCases += result.count;
      successfulBatches++;
    }
    
    // Small delay between batches
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  
  console.log('\n🎉 SQL Generation Complete!');
  console.log('============================');
  console.log(`📊 Total SQL files: ${successfulBatches}`);
  console.log(`📊 Total cases processed: ${totalCases}`);
  console.log('\n💡 Next step: Execute the SQL files to populate the database');
}

main().catch(console.error);