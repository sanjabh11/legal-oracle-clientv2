import React, { useState } from 'react'
import { useLegalOracle } from '../contexts/LegalOracleContext'
import { FileSearch, Search, BookOpen, Calendar, Scale, ExternalLink, Filter, Loader } from 'lucide-react'
import { toast } from 'sonner'

const CaselawSearch: React.FC = () => {
  const { caselaw, loading, searchCaselaw } = useLegalOracle()
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<any[]>([]) 
  const [isSearching, setIsSearching] = useState(false)
  const [filters, setFilters] = useState({
    court: '',
    jurisdiction: '',
    dateRange: 'all'
  })
  const [showFilters, setShowFilters] = useState(false)

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      toast.error('Please enter a search query')
      return
    }

    setIsSearching(true)
    try {
      const results = await searchCaselaw(searchQuery)
      setSearchResults(results)
      toast.success(`Found ${results.length} relevant cases`)
    } catch (error) {
      console.error('Search failed:', error)
      toast.error('Search failed')
    } finally {
      setIsSearching(false)
    }
  }

  const filteredResults = searchResults.filter(case_ => {
    if (filters.court && !case_.court?.toLowerCase().includes(filters.court.toLowerCase())) {
      return false
    }
    if (filters.jurisdiction && case_.jurisdiction !== filters.jurisdiction) {
      return false
    }
    return true
  })

  const displayCases = searchResults.length > 0 ? filteredResults : caselaw

  const formatDate = (dateString: string) => {
    if (!dateString) return 'Date not available'
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900 flex items-center">
          <FileSearch className="h-8 w-8 text-blue-600 mr-3" />
          Legal Caselaw Search
        </h1>
        <p className="mt-2 text-lg text-slate-600">
          Search through real legal precedents from Harvard's Caselaw Access Project
        </p>
      </div>

      {/* Search Interface */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <div className="space-y-4">
          {/* Search Bar */}
          <div className="flex space-x-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Search legal cases, precedents, or legal issues..."
                className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <button
              onClick={handleSearch}
              disabled={isSearching}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 disabled:bg-slate-400 flex items-center"
            >
              {isSearching ? (
                <>
                  <Loader className="animate-spin h-5 w-5 mr-2" />
                  Searching...
                </>
              ) : (
                <>
                  <Search className="h-5 w-5 mr-2" />
                  Search Caselaw
                </>
              )}
            </button>
          </div>

          {/* Filters */}
          <div className="flex items-center justify-between">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center text-sm font-medium text-slate-600 hover:text-slate-900"
            >
              <Filter className="h-4 w-4 mr-1" />
              {showFilters ? 'Hide Filters' : 'Show Filters'}
            </button>
            <div className="text-sm text-slate-500">
              {displayCases.length} cases available
            </div>
          </div>

          {/* Filter Options */}
          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-slate-50 rounded-lg">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Court</label>
                <input
                  type="text"
                  value={filters.court}
                  onChange={(e) => setFilters(prev => ({ ...prev, court: e.target.value }))}
                  placeholder="Filter by court name..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Jurisdiction</label>
                <select
                  value={filters.jurisdiction}
                  onChange={(e) => setFilters(prev => ({ ...prev, jurisdiction: e.target.value }))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">All Jurisdictions</option>
                  <option value="Federal">Federal</option>
                  <option value="State">State</option>
                  <option value="Local">Local</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Date Range</label>
                <select
                  value={filters.dateRange}
                  onChange={(e) => setFilters(prev => ({ ...prev, dateRange: e.target.value }))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="all">All Dates</option>
                  <option value="recent">Last 5 Years</option>
                  <option value="decade">Last 10 Years</option>
                  <option value="classic">Before 2000</option>
                </select>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Search Results */}
      <div className="space-y-4">
        {displayCases.length > 0 ? (
          displayCases.map((case_, index) => (
            <div key={case_.id || index} className="bg-white rounded-lg shadow-sm border border-slate-200 p-6 hover:shadow-md transition-shadow">
              <div className="space-y-4">
                {/* Case Header */}
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">
                      {case_.case_title}
                    </h3>
                    <div className="flex items-center space-x-4 text-sm text-slate-500">
                      <div className="flex items-center">
                        <Scale className="h-4 w-4 mr-1" />
                        {case_.court || 'Court not specified'}
                      </div>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {formatDate(case_.date_decided)}
                      </div>
                      <div className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                        {case_.jurisdiction || 'Federal'}
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-slate-400">
                    ID: {case_.case_id || 'N/A'}
                  </div>
                </div>

                {/* Case Summary */}
                <div>
                  <h4 className="text-sm font-medium text-slate-700 mb-2">Case Summary</h4>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {case_.case_summary || case_.case_text?.substring(0, 300) + '...' || 'Summary not available'}
                  </p>
                </div>

                {/* Legal Topics */}
                {case_.legal_topics && case_.legal_topics.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-slate-700 mb-2">Legal Topics</h4>
                    <div className="flex flex-wrap gap-2">
                      {case_.legal_topics.map((topic: string, topicIndex: number) => (
                        <span 
                          key={topicIndex}
                          className="bg-slate-100 text-slate-700 px-2 py-1 rounded text-xs font-medium"
                        >
                          {topic}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Judges */}
                {case_.judges && case_.judges.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-slate-700 mb-2">Judges</h4>
                    <div className="flex flex-wrap gap-2">
                      {case_.judges.map((judge: string, judgeIndex: number) => (
                        <span 
                          key={judgeIndex}
                          className="bg-purple-100 text-purple-700 px-2 py-1 rounded text-xs font-medium"
                        >
                          {judge}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-200">
                  <div className="flex items-center space-x-4 text-xs text-slate-500">
                    <span>Dataset: {case_.dataset_source || 'TeraflopAI/Caselaw-Access-Project'}</span>
                    <span>Last accessed: {formatDate(case_.last_accessed)}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center">
                      <BookOpen className="h-4 w-4 mr-1" />
                      View Full Text
                    </button>
                    <button className="text-slate-600 hover:text-slate-700 text-sm font-medium flex items-center">
                      <ExternalLink className="h-4 w-4 mr-1" />
                      Find Similar Cases
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-12 text-center">
            {isSearching ? (
              <>
                <Loader className="animate-spin h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-500 mb-2">Searching Legal Database...</h3>
                <p className="text-slate-400">
                  Searching through Harvard Caselaw Access Project data
                </p>
              </>
            ) : searchQuery && searchResults.length === 0 ? (
              <>
                <FileSearch className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-500 mb-2">No Results Found</h3>
                <p className="text-slate-400">
                  Try adjusting your search terms or filters
                </p>
              </>
            ) : (
              <>
                <BookOpen className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-500 mb-2">Legal Caselaw Database</h3>
                <p className="text-slate-400">
                  Enter search terms above to find relevant legal precedents and cases
                </p>
              </>
            )}
          </div>
        )}
      </div>

      {/* Data Source Information */}
      <div className="bg-green-50 rounded-lg border border-green-200 p-6">
        <div className="flex items-start">
          <BookOpen className="h-6 w-6 text-green-600 mt-1" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-green-900">Real Legal Data</h3>
            <p className="mt-1 text-sm text-green-700">
              This database contains real legal cases from Harvard Law School's Caselaw Access Project, 
              integrated via HuggingFace datasets. All cases represent authentic legal precedents and 
              judicial decisions from various courts and jurisdictions.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default CaselawSearch
