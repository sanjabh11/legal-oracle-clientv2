// Data population script for Legal Oracle platform
// This script populates the database with sample data to enable full functionality testing

import { dataPopulation } from '../src/lib/supabase.ts';

async function populateDatabase() {
  console.log('Starting Legal Oracle database population...');
  
  try {
    // Populate sample data
    const result = await dataPopulation.populateSampleData();
    console.log('Database population results:', result);
    
    // Optional: Stream additional data from HuggingFace
    // const streamResult = await dataPopulation.streamHuggingFaceData(50);
    // console.log('HuggingFace streaming results:', streamResult);
    
    console.log('✅ Database population completed successfully!');
    console.log('The Legal Oracle platform is now ready with sample data.');
    
  } catch (error) {
    console.error('❌ Error during database population:', error);
    process.exit(1);
  }
}

// Run the population script
if (import.meta.main) {
  populateDatabase();
}

export { populateDatabase };