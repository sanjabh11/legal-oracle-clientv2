import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { legalOracleDB } from '../lib/supabase'
import { huggingFaceAI } from '../lib/huggingface'
import { gameTheoryCalculator } from '../lib/game-theory'
import { toast } from 'sonner'

interface LegalOracleContextType {
  // Data states
  cases: any[]
  caselaw: any[]
  judges: any[]
  strategicPatterns: any[]
  scenarios: any[]
  
  // Loading states
  loading: {
    cases: boolean
    caselaw: boolean
    judges: boolean
    patterns: boolean
    scenarios: boolean
    analysis: boolean
  }
  
  // Analysis results
  analysisResults: {
    outcome_prediction: any
    judge_analysis: any
    similar_cases: any[]
    strategy_optimization: any
    nash_equilibrium: any
    settlement_analysis: any
  }
  
  // Data fetching methods
  loadCases: () => Promise<void>
  loadCaselaw: (limit?: number) => Promise<void>
  loadJudges: () => Promise<void>
  loadStrategicPatterns: () => Promise<void>
  loadScenarios: () => Promise<void>
  
  // Search methods
  searchCaselaw: (query: string) => Promise<any[]>
  searchJudges: (query: string) => Promise<any[]>
  
  // Analysis methods
  predictOutcome: (caseData: any) => Promise<any>
  analyzeJudge: (judgeData: any, caseType: string) => Promise<any>
  findSimilarCases: (caseText: string, legalIssues: string[]) => Promise<any[]>
  optimizeStrategy: (caseDetails: any) => Promise<any>
  calculateNashEquilibrium: (scenario: any) => Promise<any>
  analyzeSettlement: (caseDetails: any) => Promise<any>
  
  // Utility methods
  clearResults: () => void
  setLoading: (key: string, value: boolean) => void
}

const LegalOracleContext = createContext<LegalOracleContextType | undefined>(undefined)

interface LegalOracleProviderProps {
  children: ReactNode
}

export const LegalOracleProvider: React.FC<LegalOracleProviderProps> = ({ children }) => {
  // Data states
  const [cases, setCases] = useState<any[]>([])
  const [caselaw, setCaselaw] = useState<any[]>([])
  const [judges, setJudges] = useState<any[]>([])
  const [strategicPatterns, setStrategicPatterns] = useState<any[]>([])
  const [scenarios, setScenarios] = useState<any[]>([])
  
  // Loading states
  const [loading, setLoadingState] = useState({
    cases: false,
    caselaw: false,
    judges: false,
    patterns: false,
    scenarios: false,
    analysis: false
  })
  
  // Analysis results
  const [analysisResults, setAnalysisResults] = useState({
    outcome_prediction: null,
    judge_analysis: null,
    similar_cases: [],
    strategy_optimization: null,
    nash_equilibrium: null,
    settlement_analysis: null
  })
  
  // Helper function to update loading states
  const setLoading = (key: string, value: boolean) => {
    setLoadingState(prev => ({ ...prev, [key]: value }))
  }
  
  // Data loading methods
  const loadCases = async () => {
    try {
      setLoading('cases', true)
      const data = await legalOracleDB.getCases()
      setCases(data || [])
      console.log('Loaded cases:', data?.length || 0)
    } catch (error) {
      console.error('Failed to load cases:', error)
      toast.error('Failed to load legal cases')
    } finally {
      setLoading('cases', false)
    }
  }
  
  const loadCaselaw = async (limit = 10) => {
    try {
      setLoading('caselaw', true)
      const data = await legalOracleDB.getCaselaw(limit)
      setCaselaw(data || [])
      console.log('Loaded caselaw:', data?.length || 0)
    } catch (error) {
      console.error('Failed to load caselaw:', error)
      toast.error('Failed to load caselaw data')
    } finally {
      setLoading('caselaw', false)
    }
  }
  
  const loadJudges = async () => {
    try {
      setLoading('judges', true)
      const data = await legalOracleDB.getJudgePatterns()
      setJudges(data || [])
      console.log('Loaded judges:', data?.length || 0)
    } catch (error) {
      console.error('Failed to load judges:', error)
      toast.error('Failed to load judge data')
    } finally {
      setLoading('judges', false)
    }
  }
  
  const loadStrategicPatterns = async () => {
    try {
      setLoading('patterns', true)
      const data = await legalOracleDB.getStrategicPatterns()
      setStrategicPatterns(data || [])
      console.log('Loaded strategic patterns:', data?.length || 0)
    } catch (error) {
      console.error('Failed to load strategic patterns:', error)
      toast.error('Failed to load strategic patterns')
    } finally {
      setLoading('patterns', false)
    }
  }
  
  const loadScenarios = async () => {
    try {
      setLoading('scenarios', true)
      const data = await legalOracleDB.getLegalScenarios()
      setScenarios(data || [])
      console.log('Loaded scenarios:', data?.length || 0)
    } catch (error) {
      console.error('Failed to load scenarios:', error)
      toast.error('Failed to load legal scenarios')
    } finally {
      setLoading('scenarios', false)
    }
  }
  
  // Search methods
  const searchCaselaw = async (query: string) => {
    try {
      const results = await legalOracleDB.searchCaselaw(query)
      return results || []
    } catch (error) {
      console.error('Caselaw search failed:', error)
      toast.error('Caselaw search failed')
      return []
    }
  }
  
  const searchJudges = async (query: string) => {
    try {
      const results = await legalOracleDB.searchJudges(query)
      return results || []
    } catch (error) {
      console.error('Judge search failed:', error)
      toast.error('Judge search failed')
      return []
    }
  }
  
  // Analysis methods
  const predictOutcome = async (caseData: any) => {
    try {
      setLoading('analysis', true)
      const prediction = await huggingFaceAI.predictCaseOutcome(
        caseData.summary || caseData.case_description || '',
        caseData.case_type || 'civil',
        caseData.jurisdiction || 'federal'
      )
      
      setAnalysisResults(prev => ({ ...prev, outcome_prediction: prediction }))
      toast.success('Case outcome analysis completed')
      return prediction
    } catch (error) {
      console.error('Outcome prediction failed:', error)
      toast.error('Outcome prediction failed')
      return null
    } finally {
      setLoading('analysis', false)
    }
  }
  
  const analyzeJudge = async (judgeData: any, caseType: string) => {
    try {
      setLoading('analysis', true)
      const analysis = await huggingFaceAI.analyzeJudgeBehavior(
        judgeData.judge_name || '',
        judgeData.decision_patterns || [],
        caseType
      )
      
      setAnalysisResults(prev => ({ ...prev, judge_analysis: analysis }))
      toast.success('Judge behavior analysis completed')
      return analysis
    } catch (error) {
      console.error('Judge analysis failed:', error)
      toast.error('Judge analysis failed')
      return null
    } finally {
      setLoading('analysis', false)
    }
  }
  
  const findSimilarCases = async (caseText: string, legalIssues: string[]) => {
    try {
      setLoading('analysis', true)
      const similarities = await huggingFaceAI.findSimilarCases(caseText, legalIssues, caselaw)
      
      setAnalysisResults(prev => ({ ...prev, similar_cases: similarities }))
      toast.success(`Found ${similarities.length} similar cases`)
      return similarities
    } catch (error) {
      console.error('Similar case search failed:', error)
      toast.error('Similar case search failed')
      return []
    } finally {
      setLoading('analysis', false)
    }
  }
  
  const optimizeStrategy = async (caseDetails: any) => {
    try {
      setLoading('analysis', true)
      const strategy = await huggingFaceAI.generateLegalStrategy(caseDetails)
      
      setAnalysisResults(prev => ({ ...prev, strategy_optimization: strategy }))
      toast.success('Strategic optimization completed')
      return strategy
    } catch (error) {
      console.error('Strategy optimization failed:', error)
      toast.error('Strategy optimization failed')
      return null
    } finally {
      setLoading('analysis', false)
    }
  }
  
  const calculateNashEquilibrium = async (scenario: any) => {
    try {
      setLoading('analysis', true)
      
      // Get strategic pattern data for the scenario
      const pattern = strategicPatterns.find(p => 
        p.legal_context === scenario.legal_domain || 
        p.scenario_type === scenario.player_count > 2 ? 'multi_party' : 'bilateral'
      )
      
      if (!pattern) {
        throw new Error('No strategic pattern found for scenario')
      }
      
      const equilibrium = gameTheoryCalculator.calculateNashEquilibrium(
        pattern.payoff_matrix,
        Object.keys(pattern.payoff_matrix)
      )
      
      setAnalysisResults(prev => ({ ...prev, nash_equilibrium: equilibrium }))
      toast.success('Nash equilibrium analysis completed')
      return equilibrium
    } catch (error) {
      console.error('Nash equilibrium calculation failed:', error)
      toast.error('Nash equilibrium calculation failed')
      return null
    } finally {
      setLoading('analysis', false)
    }
  }
  
  const analyzeSettlement = async (caseDetails: any) => {
    try {
      setLoading('analysis', true)
      
      // Find relevant strategic pattern
      const pattern = strategicPatterns.find(p => 
        p.legal_context === 'litigation' || 
        p.pattern_name.toLowerCase().includes('settlement')
      )
      
      const settlement = gameTheoryCalculator.calculateSettlementProbability(
        caseDetails,
        pattern?.nash_equilibrium_data
      )
      
      setAnalysisResults(prev => ({ ...prev, settlement_analysis: settlement }))
      toast.success('Settlement analysis completed')
      return settlement
    } catch (error) {
      console.error('Settlement analysis failed:', error)
      toast.error('Settlement analysis failed')
      return null
    } finally {
      setLoading('analysis', false)
    }
  }
  
  // Utility methods
  const clearResults = () => {
    setAnalysisResults({
      outcome_prediction: null,
      judge_analysis: null,
      similar_cases: [],
      strategy_optimization: null,
      nash_equilibrium: null,
      settlement_analysis: null
    })
  }
  
  // Load initial data on mount
  useEffect(() => {
    const initializeData = async () => {
      console.log('Initializing Legal Oracle data...')
      await Promise.all([
        loadCases(),
        loadCaselaw(20),
        loadJudges(),
        loadStrategicPatterns(),
        loadScenarios()
      ])
      console.log('Legal Oracle initialization complete')
    }
    
    initializeData()
  }, [])
  
  const value: LegalOracleContextType = {
    // Data states
    cases,
    caselaw,
    judges,
    strategicPatterns,
    scenarios,
    
    // Loading states
    loading,
    
    // Analysis results
    analysisResults,
    
    // Data methods
    loadCases,
    loadCaselaw,
    loadJudges,
    loadStrategicPatterns,
    loadScenarios,
    
    // Search methods
    searchCaselaw,
    searchJudges,
    
    // Analysis methods
    predictOutcome,
    analyzeJudge,
    findSimilarCases,
    optimizeStrategy,
    calculateNashEquilibrium,
    analyzeSettlement,
    
    // Utility methods
    clearResults,
    setLoading
  }
  
  return (
    <LegalOracleContext.Provider value={value}>
      {children}
    </LegalOracleContext.Provider>
  )
}

export const useLegalOracle = () => {
  const context = useContext(LegalOracleContext)
  if (context === undefined) {
    throw new Error('useLegalOracle must be used within a LegalOracleProvider')
  }
  return context
}
