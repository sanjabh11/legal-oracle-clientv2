// Direct database population using fetch API
const supabaseUrl = 'https://qnymbecjgeaoxsfphrti.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFueW1iZWNqZ2Vhb3hzZnBocnRpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYwMTczNjEsImV4cCI6MjA3MTU5MzM2MX0.6wAWe5GdKzTOjVa0eUVhDJ4IwczseO9A83uwXlDg0DU'
const huggingFaceToken = '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'

// Fetch real legal cases from HuggingFace
async function fetchLegalCases(limit = 20) {
  console.log(`Fetching ${limit} real legal cases from HuggingFace...`)
  
  try {
    const response = await fetch(
      `https://datasets-server.huggingface.co/rows?dataset=TeraflopAI%2FCaselaw-Access-Project&config=default&split=train&offset=0&length=${limit}`,
      {
        headers: {
          'Authorization': `Bearer ${huggingFaceToken}`,
          'Content-Type': 'application/json'
        }
      }
    )
    
    if (!response.ok) {
      throw new Error(`API Error: ${response.status}`)
    }
    
    const data = await response.json()
    console.log(`✅ Fetched ${data.rows?.length || 0} legal cases`)
    return data.rows || []
  } catch (error) {
    console.error('Error fetching legal cases:', error)
    return []
  }
}

// Insert data into Supabase table
async function insertIntoTable(tableName, data) {
  console.log(`Inserting ${data.length} records into ${tableName}...`)
  
  try {
    const response = await fetch(`${supabaseUrl}/rest/v1/${tableName}`, {
      method: 'POST',
      headers: {
        'apikey': supabaseKey,
        'Authorization': `Bearer ${supabaseKey}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify(data)
    })
    
    if (!response.ok) {
      const error = await response.text()
      console.error(`Error inserting into ${tableName}:`, error)
      return false
    }
    
    console.log(`✅ Successfully inserted ${data.length} records into ${tableName}`)
    return true
  } catch (error) {
    console.error(`Error inserting into ${tableName}:`, error)
    return false
  }
}

// Populate caselaw cache with real data
async function populateCaselawCache(cases) {
  const caselawData = cases.map((caseRow, index) => {
    const row = caseRow.row || caseRow
    
    // Parse metadata if it exists
    let metadata = {}
    try {
      metadata = typeof row.metadata === 'string' ? JSON.parse(row.metadata) : row.metadata || {}
    } catch (e) {
      metadata = {}
    }
    
    return {
      case_id: row.id || `hf_case_${index}_${Date.now()}`,
      dataset_source: 'TeraflopAI/Caselaw-Access-Project',
      case_title: metadata.title || `Legal Case ${index + 1}`,
      court: metadata.court || 'Federal Court',
      date_decided: row.created ? new Date(row.created).toISOString().split('T')[0] : '2024-01-01',
      jurisdiction: metadata.jurisdiction || 'Federal',
      case_text: row.text ? row.text.substring(0, 10000) : 'Case text from HuggingFace dataset',
      case_summary: row.text ? row.text.substring(0, 500) + '...' : 'Real legal case from Caselaw Access Project',
      legal_citations: [],
      judges: [],
      outcome: 'Decided',
      legal_topics: ['general law'],
      fetch_timestamp: new Date().toISOString(),
      last_accessed: new Date().toISOString()
    }
  })
  
  return await insertIntoTable('caselaw_cache', caselawData)
}

// Create sample legal cases for analysis
async function createSampleLegalCases() {
  const sampleCases = [
    {
      case_name: 'AI Patents Inc. v. Tech Innovation Corp',
      case_number: 'CV-2024-001001',
      case_type: 'civil',
      jurisdiction: 'federal',
      court_level: 'District Court',
      filed_date: '2024-01-15',
      case_status: 'active',
      summary: 'Patent dispute involving artificial intelligence algorithms and machine learning technology',
      legal_issues: ['patent infringement', 'ai technology', 'trade secrets'],
      outcome: 'pending',
      precedent_value: 0.85,
      citation_count: 23,
      legal_principles: {
        'primary': 'Intellectual Property Law',
        'secondary': ['Patent Protection', 'AI Innovation Rights']
      }
    },
    {
      case_name: 'Environmental Coalition v. Energy Development LLC',
      case_number: 'CV-2024-002002',
      case_type: 'civil',
      jurisdiction: 'federal',
      court_level: 'Appeals Court',
      filed_date: '2024-02-28',
      case_status: 'active',
      summary: 'Environmental protection lawsuit challenging renewable energy project approvals',
      legal_issues: ['environmental protection', 'regulatory compliance', 'public interest'],
      outcome: 'pending',
      precedent_value: 0.78,
      citation_count: 15,
      legal_principles: {
        'primary': 'Environmental Law',
        'secondary': ['NEPA Compliance', 'Public Participation']
      }
    },
    {
      case_name: 'Digital Privacy Foundation v. Social Media Platform',
      case_number: 'CV-2024-003003',
      case_type: 'civil',
      jurisdiction: 'federal',
      court_level: 'District Court',
      filed_date: '2024-03-10',
      case_status: 'active',
      summary: 'Class action lawsuit regarding user data privacy and algorithmic discrimination',
      legal_issues: ['data privacy', 'algorithmic bias', 'consumer protection'],
      outcome: 'pending',
      precedent_value: 0.92,
      citation_count: 34,
      legal_principles: {
        'primary': 'Privacy Law',
        'secondary': ['GDPR Compliance', 'Algorithmic Accountability']
      }
    }
  ]
  
  return await insertIntoTable('legal_cases', sampleCases)
}

// Create judge behavioral patterns
async function createJudgePatterns() {
  const judgeData = [
    {
      judge_name: 'Hon. Elena Rodriguez',
      court: 'US District Court, Northern District of California',
      jurisdiction: 'federal',
      appointment_date: '2019-06-15',
      judicial_philosophy: 'progressive',
      case_types_handled: ['technology', 'privacy', 'intellectual property'],
      decision_patterns: {
        'tech_cases': { 'plaintiff_win_rate': 0.68, 'innovation_protection': 0.82 },
        'privacy_cases': { 'consumer_protection_rate': 0.75, 'corporate_liability': 0.63 }
      },
      average_sentence_length: null,
      reversal_rate: 0.12,
      political_leanings: 'moderate-progressive',
      precedent_adherence_score: 0.79,
      cases_decided: 145
    },
    {
      judge_name: 'Hon. Marcus Chen',
      court: 'US Court of Appeals, 9th Circuit',
      jurisdiction: 'federal',
      appointment_date: '2016-09-22',
      judicial_philosophy: 'textualist',
      case_types_handled: ['environmental', 'regulatory', 'administrative'],
      decision_patterns: {
        'environmental_cases': { 'agency_support_rate': 0.45, 'industry_deference': 0.55 },
        'regulatory_challenges': { 'chevron_application': 0.67, 'strict_scrutiny': 0.34 }
      },
      average_sentence_length: null,
      reversal_rate: 0.18,
      political_leanings: 'conservative',
      precedent_adherence_score: 0.88,
      cases_decided: 203
    }
  ]
  
  return await insertIntoTable('judge_patterns', judgeData)
}

// Create strategic patterns for game theory
async function createStrategicPatterns() {
  const patterns = [
    {
      pattern_name: 'Multi-Party Patent Settlement Game',
      legal_context: 'litigation',
      scenario_type: 'multi_party',
      pattern_description: 'Complex patent dispute with multiple defendants and cross-licensing opportunities',
      nash_equilibrium_data: {
        'strategies': ['aggressive_defense', 'cooperative_licensing', 'settlement_early'],
        'equilibrium_type': 'mixed_strategy',
        'cooperation_probability': 0.67
      },
      payoff_matrix: {
        'patent_holder': { 'litigate': [2000000, 1500000], 'license': [800000, 1200000] },
        'defendant_a': { 'fight': [-1000000, -500000], 'settle': [-400000, -600000] },
        'defendant_b': { 'fight': [-800000, -400000], 'settle': [-350000, -550000] }
      },
      success_probability: 0.71
    },
    {
      pattern_name: 'Environmental Regulatory Compliance Coalition',
      legal_context: 'regulatory',
      scenario_type: 'multi_party',
      pattern_description: 'Multiple companies facing environmental regulations with collective action options',
      nash_equilibrium_data: {
        'strategies': ['full_compliance', 'minimal_compliance', 'regulatory_challenge'],
        'equilibrium_type': 'cooperative',
        'collective_action_benefit': 0.58
      },
      payoff_matrix: {
        'company_group_a': { 'comply': [900000, 1100000], 'challenge': [1400000, 600000] },
        'company_group_b': { 'comply': [850000, 1050000], 'challenge': [1300000, 550000] },
        'regulators': { 'enforce': [500000, 800000], 'negotiate': [700000, 900000] }
      },
      success_probability: 0.63
    }
  ]
  
  return await insertIntoTable('strategic_patterns', patterns)
}

// Main setup function
async function setupDatabase() {
  console.log('🚀 Legal Oracle Database Setup Started')
  console.log('========================================\n')
  
  // Fetch real legal cases from HuggingFace
  const cases = await fetchLegalCases(15) // Start with 15 real cases
  
  // Populate all tables
  const results = await Promise.all([
    cases.length > 0 ? populateCaselawCache(cases) : Promise.resolve(false),
    createSampleLegalCases(),
    createJudgePatterns(),
    createStrategicPatterns()
  ])
  
  console.log('\n📋 Setup Results:')
  console.log('===================')
  console.log(`Caselaw Cache: ${results[0] ? '✅' : '❌'} (Real HuggingFace data)`)
  console.log(`Legal Cases: ${results[1] ? '✅' : '❌'} (Sample cases for analysis)`)
  console.log(`Judge Patterns: ${results[2] ? '✅' : '❌'} (Behavioral data)`)
  console.log(`Strategic Patterns: ${results[3] ? '✅' : '❌'} (Game theory data)`)
  
  const success = results.every(r => r)
  
  if (success) {
    console.log('\n🎉 Database setup completed successfully!')
    console.log('Ready for client-side Legal Oracle implementation')
  } else {
    console.log('\n⚠️  Some operations failed. Check logs above.')
  }
  
  return success
}

// Run setup
setupDatabase().catch(console.error)