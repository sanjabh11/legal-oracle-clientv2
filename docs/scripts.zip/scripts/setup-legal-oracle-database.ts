import { createClient } from '@supabase/supabase-js'

// User-provided Supabase credentials for qnymbecjgeaoxsfphrti project
const supabaseUrl = 'https://qnymbecjgeaoxsfphrti.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFueW1iZWNqZ2Vhb3hzZnBocnRpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYwMTczNjEsImV4cCI6MjA3MTU5MzM2MX0.6wAWe5GdKzTOjVa0eUVhDJ4IwczseO9A83uwXlDg0DU'
const huggingFaceToken = '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'

const supabase = createClient(supabaseUrl, supabaseKey)

// Test database connection
async function testConnection() {
  try {
    console.log('Testing Supabase connection...')
    const { data, error } = await supabase
      .from('legal_cases')
      .select('count')
      .limit(1)
    
    if (error) {
      console.error('Connection error:', error)
      return false
    }
    
    console.log('✅ Database connection successful')
    return true
  } catch (err) {
    console.error('Connection failed:', err)
    return false
  }
}

// Create database schema if needed
async function setupSchema() {
  console.log('Setting up database schema...')
  
  // Enable extensions
  const extensions = [
    'CREATE EXTENSION IF NOT EXISTS "uuid-ossp";',
    'CREATE EXTENSION IF NOT EXISTS vector;'
  ]
  
  for (const ext of extensions) {
    try {
      const { error } = await supabase.rpc('exec_sql', { sql: ext })
      if (error && !error.message.includes('already exists')) {
        console.error('Extension error:', error)
      }
    } catch (err) {
      console.log('Extension setup (may already exist):', ext)
    }
  }
  
  console.log('✅ Schema setup complete')
}

// Fetch legal cases from HuggingFace dataset
async function fetchCaselawData(limit = 100) {
  console.log(`Fetching ${limit} cases from TeraflopAI/Caselaw-Access-Project...`)
  
  try {
    const response = await fetch(
      `https://datasets-server.huggingface.co/rows?dataset=TeraflopAI%2FCaselaw-Access-Project&config=default&split=train&offset=0&length=${limit}`,
      {
        headers: {
          'Authorization': `Bearer ${huggingFaceToken}`,
          'Content-Type': 'application/json'
        }
      }
    )
    
    if (!response.ok) {
      throw new Error(`HuggingFace API error: ${response.status} ${response.statusText}`)
    }
    
    const data = await response.json()
    console.log(`✅ Fetched ${data.rows?.length || 0} legal cases`)
    return data.rows || []
  } catch (error) {
    console.error('Error fetching caselaw data:', error)
    return []
  }
}

// Populate caselaw_cache table with real data
async function populateCaselawCache(cases) {
  console.log('Populating caselaw_cache table...')
  
  const batchSize = 10
  let inserted = 0
  
  for (let i = 0; i < cases.length; i += batchSize) {
    const batch = cases.slice(i, i + batchSize)
    
    const caselawData = batch.map((caseData, index) => {
      const row = caseData.row || caseData
      
      return {
        case_id: `hf_case_${i + index}_${Date.now()}`,
        dataset_source: 'TeraflopAI/Caselaw-Access-Project',
        case_title: row.name || row.title || `Case ${i + index + 1}`,
        court: row.court || row.jurisdiction || 'Unknown Court',
        date_decided: row.decision_date || row.date || new Date().toISOString().split('T')[0],
        jurisdiction: row.jurisdiction || 'Federal',
        case_text: row.text || row.case_text || row.content || 'Case text unavailable',
        case_summary: row.summary || (row.text ? row.text.substring(0, 500) + '...' : 'No summary available'),
        legal_citations: row.citations || [],
        judges: row.judges || [],
        outcome: row.outcome || row.decision || 'Unknown',
        legal_topics: row.topics || row.legal_areas || [],
        fetch_timestamp: new Date().toISOString(),
        last_accessed: new Date().toISOString()
      }
    })
    
    const { data, error } = await supabase
      .from('caselaw_cache')
      .insert(caselawData)
    
    if (error) {
      console.error('Error inserting batch:', error)
    } else {
      inserted += caselawData.length
      console.log(`✅ Inserted batch ${Math.floor(i / batchSize) + 1}, total: ${inserted}`)
    }
    
    // Small delay to avoid overwhelming the database
    await new Promise(resolve => setTimeout(resolve, 100))
  }
  
  return inserted
}

// Create sample legal cases for analysis
async function createSampleLegalCases() {
  console.log('Creating sample legal cases...')
  
  const sampleCases = [
    {
      case_name: 'Tech Innovation Corp v. Digital Solutions LLC',
      case_number: 'CV-2024-001234',
      case_type: 'civil',
      jurisdiction: 'federal',
      court_level: 'District Court',
      filed_date: '2024-01-15',
      case_status: 'active',
      summary: 'Patent infringement dispute involving AI technology algorithms',
      legal_issues: ['patent infringement', 'trade secrets', 'injunctive relief'],
      outcome: 'pending',
      precedent_value: 0.75,
      citation_count: 12,
      legal_principles: {
        'primary': 'Patent Law',
        'secondary': ['Trade Secret Protection', 'Injunctive Relief Standards']
      }
    },
    {
      case_name: 'Environmental Protection Alliance v. State Energy Department',
      case_number: 'CV-2024-005678',
      case_type: 'civil',
      jurisdiction: 'federal',
      court_level: 'Appeals Court',
      filed_date: '2024-03-22',
      case_status: 'active',
      summary: 'Challenge to new environmental regulations on renewable energy projects',
      legal_issues: ['environmental law', 'administrative law', 'regulatory compliance'],
      outcome: 'pending',
      precedent_value: 0.85,
      citation_count: 28,
      legal_principles: {
        'primary': 'Environmental Law',
        'secondary': ['Administrative Procedure Act', 'Regulatory Review']
      }
    }
  ]
  
  const { data, error } = await supabase
    .from('legal_cases')
    .insert(sampleCases)
  
  if (error) {
    console.error('Error creating sample cases:', error)
  } else {
    console.log(`✅ Created ${sampleCases.length} sample legal cases`)
  }
}

// Create judge behavioral patterns
async function createJudgePatterns() {
  console.log('Creating judge behavioral patterns...')
  
  const judgeData = [
    {
      judge_name: 'Hon. Sarah Mitchell',
      court: 'US District Court, Northern District of California',
      jurisdiction: 'federal',
      appointment_date: '2018-08-15',
      judicial_philosophy: 'textualist',
      case_types_handled: ['patent', 'contract', 'civil rights'],
      decision_patterns: {
        'patent_cases': { 'plaintiff_win_rate': 0.65, 'injunction_rate': 0.45 },
        'contract_disputes': { 'summary_judgment_rate': 0.35 }
      },
      average_sentence_length: null,
      reversal_rate: 0.15,
      political_leanings: 'moderate',
      precedent_adherence_score: 0.82,
      cases_decided: 234
    },
    {
      judge_name: 'Hon. Robert Chen',
      court: 'US Court of Appeals, 9th Circuit',
      jurisdiction: 'federal',
      appointment_date: '2015-03-10',
      judicial_philosophy: 'pragmatic',
      case_types_handled: ['environmental', 'regulatory', 'administrative'],
      decision_patterns: {
        'environmental_cases': { 'agency_deference_rate': 0.58, 'standing_dismissal_rate': 0.22 },
        'regulatory_challenges': { 'chevron_deference_rate': 0.73 }
      },
      average_sentence_length: null,
      reversal_rate: 0.12,
      political_leanings: 'moderate-liberal',
      precedent_adherence_score: 0.78,
      cases_decided: 189
    }
  ]
  
  const { data, error } = await supabase
    .from('judge_patterns')
    .insert(judgeData)
  
  if (error) {
    console.error('Error creating judge patterns:', error)
  } else {
    console.log(`✅ Created ${judgeData.length} judge behavioral patterns`)
  }
}

// Create strategic patterns for game theory
async function createStrategicPatterns() {
  console.log('Creating strategic patterns...')
  
  const patterns = [
    {
      pattern_name: 'Patent Settlement Nash Equilibrium',
      legal_context: 'litigation',
      scenario_type: 'bilateral',
      pattern_description: 'Two-party patent dispute with settlement vs trial decision points',
      nash_equilibrium_data: {
        'strategies': ['settle_early', 'litigate_to_trial'],
        'equilibrium': 'mixed_strategy',
        'settlement_probability': 0.73
      },
      payoff_matrix: {
        'plaintiff': { 'settle': [500000, 750000], 'trial': [0, 2000000] },
        'defendant': { 'settle': [-500000, -750000], 'trial': [-3000000, 0] }
      },
      success_probability: 0.68
    },
    {
      pattern_name: 'Multi-Party Environmental Compliance',
      legal_context: 'regulatory',
      scenario_type: 'multi_party',
      pattern_description: 'Multiple companies facing environmental regulations with cooperation vs defection strategies',
      nash_equilibrium_data: {
        'strategies': ['comply', 'lobby_against', 'partial_comply'],
        'equilibrium': 'partial_comply',
        'cooperation_index': 0.45
      },
      payoff_matrix: {
        'company_a': { 'comply': [800000, 900000], 'lobby': [1200000, 500000] },
        'company_b': { 'comply': [850000, 920000], 'lobby': [1100000, 480000] },
        'company_c': { 'comply': [780000, 880000], 'lobby': [1250000, 520000] }
      },
      success_probability: 0.54
    }
  ]
  
  const { data, error } = await supabase
    .from('strategic_patterns')
    .insert(patterns)
  
  if (error) {
    console.error('Error creating strategic patterns:', error)
  } else {
    console.log(`✅ Created ${patterns.length} strategic patterns`)
  }
}

// Main setup function
export async function setupLegalOracleDatabase() {
  console.log('🚀 Starting Legal Oracle Database Setup')
  console.log('=====================================\n')
  
  // Test connection
  const connected = await testConnection()
  if (!connected) {
    console.error('❌ Database connection failed. Please check credentials.')
    return false
  }
  
  // Setup schema
  await setupSchema()
  
  // Fetch and populate real caselaw data
  const cases = await fetchCaselawData(50) // Start with 50 cases
  if (cases.length > 0) {
    await populateCaselawCache(cases)
  }
  
  // Create sample data
  await createSampleLegalCases()
  await createJudgePatterns()
  await createStrategicPatterns()
  
  console.log('\n🎉 Legal Oracle Database Setup Complete!')
  console.log('=========================================')
  console.log('Database populated with real legal data from HuggingFace')
  console.log('Ready for client-side AI integration')
  
  return true
}

// Run setup if called directly
if (import.meta.main) {
  setupLegalOracleDatabase()
    .then(success => {
      if (success) {
        console.log('✅ Setup completed successfully')
      } else {
        console.error('❌ Setup failed')
        process.exit(1)
      }
    })
    .catch(error => {
      console.error('❌ Setup error:', error)
      process.exit(1)
    })
}
