import React from 'react'
import { useLegalOracle } from '../contexts/LegalOracleContext'
import { 
  BarChart3, 
  FileSearch, 
  Gavel, 
  TrendingUp, 
  Target, 
  Users, 
  Brain,
  Scale,
  Activity,
  Database
} from 'lucide-react'

const Dashboard: React.FC = () => {
  const { cases, caselaw, judges, strategicPatterns, scenarios, loading } = useLegalOracle()

  const stats = [
    {
      name: 'Active Legal Cases',
      value: cases.length,
      icon: Scale,
      change: '+12%',
      changeType: 'positive' as const
    },
    {
      name: 'Caselaw Database',
      value: caselaw.length,
      icon: Database,
      change: 'Real Data from HuggingFace',
      changeType: 'neutral' as const
    },
    {
      name: 'Judge Behavioral Patterns',
      value: judges.length,
      icon: Gavel,
      change: 'Updated Daily',
      changeType: 'positive' as const
    },
    {
      name: 'Strategic Game Patterns',
      value: strategicPatterns.length,
      icon: Brain,
      change: 'Nash Equilibrium Ready',
      changeType: 'positive' as const
    }
  ]

  const features = [
    {
      name: 'Case Outcome Prediction',
      description: 'AI-powered analysis using HuggingFace models for accurate legal outcome predictions',
      icon: Target,
      href: '/predict-outcome',
      color: 'bg-blue-500'
    },
    {
      name: 'Caselaw Research',
      description: 'Search through real legal precedents from Harvard Caselaw Access Project',
      icon: FileSearch,
      href: '/caselaw-search',
      color: 'bg-green-500'
    },
    {
      name: 'Judge Behavior Analysis',
      description: 'Analyze judicial patterns and predict decision-making tendencies',
      icon: Gavel,
      href: '/judge-analysis',
      color: 'bg-purple-500'
    },
    {
      name: 'Legal Trend Forecasting',
      description: 'Predict future legal trends based on historical data and AI analysis',
      icon: TrendingUp,
      href: '/trend-forecasting',
      color: 'bg-orange-500'
    },
    {
      name: 'Nash Equilibrium Analysis',
      description: 'Game theory calculations for optimal legal strategies',
      icon: Activity,
      href: '/nash-equilibrium',
      color: 'bg-red-500'
    },
    {
      name: 'Multi-Player Game Theory',
      description: 'Complex strategic analysis for multi-party legal scenarios',
      icon: Users,
      href: '/multiplayer-scenarios',
      color: 'bg-indigo-500'
    }
  ]

  if (loading.cases || loading.caselaw || loading.judges) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        <span className="ml-3 text-lg font-medium text-slate-600">Loading Legal Oracle Platform...</span>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Legal Oracle Dashboard</h1>
        <p className="mt-2 text-lg text-slate-600">
          AI-Powered Legal Strategic Intelligence Platform with Real Data Integration
        </p>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <div key={stat.name} className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Icon className="h-8 w-8 text-blue-600" />
                </div>
                <div className="ml-4 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-slate-500 truncate">{stat.name}</dt>
                    <dd className="flex items-baseline">
                      <div className="text-2xl font-semibold text-slate-900">{stat.value}</div>
                      <div className={`ml-2 flex items-baseline text-sm font-semibold ${
                        stat.changeType === 'positive' ? 'text-green-600' : 
                        stat.changeType === 'negative' ? 'text-red-600' : 'text-slate-600'
                      }`}>
                        {stat.change}
                      </div>
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200">
        <div className="px-6 py-4 border-b border-slate-200">
          <h3 className="text-lg font-medium text-slate-900">Real Legal Data Overview</h3>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div>
              <h4 className="text-sm font-medium text-slate-500 mb-3">Recent Legal Cases</h4>
              <div className="space-y-2">
                {cases.slice(0, 3).map((case_, index) => (
                  <div key={case_.id || index} className="text-sm">
                    <div className="font-medium text-slate-900">{case_.case_name}</div>
                    <div className="text-slate-500">{case_.case_type} • {case_.jurisdiction}</div>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-slate-500 mb-3">Judge Behavioral Patterns</h4>
              <div className="space-y-2">
                {judges.slice(0, 3).map((judge, index) => (
                  <div key={judge.id || index} className="text-sm">
                    <div className="font-medium text-slate-900">{judge.judge_name}</div>
                    <div className="text-slate-500">
                      {judge.cases_decided} cases • {Math.round((judge.precedent_adherence_score || 0) * 100)}% precedent adherence
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-slate-500 mb-3">Strategic Game Patterns</h4>
              <div className="space-y-2">
                {strategicPatterns.slice(0, 3).map((pattern, index) => (
                  <div key={pattern.id || index} className="text-sm">
                    <div className="font-medium text-slate-900">{pattern.pattern_name}</div>
                    <div className="text-slate-500">
                      {pattern.legal_context} • {Math.round((pattern.success_probability || 0) * 100)}% success rate
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Grid */}
      <div>
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Legal Intelligence Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => {
            const Icon = feature.icon
            return (
              <div key={feature.name} className="bg-white rounded-lg shadow-sm border border-slate-200 hover:shadow-md transition-shadow">
                <div className="p-6">
                  <div className="flex items-center">
                    <div className={`flex-shrink-0 w-10 h-10 rounded-lg ${feature.color} flex items-center justify-center`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-slate-900">{feature.name}</h3>
                    </div>
                  </div>
                  <p className="mt-4 text-sm text-slate-600">{feature.description}</p>
                  <div className="mt-4">
                    <a
                      href={feature.href}
                      className="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-500"
                    >
                      Explore Feature
                      <svg className="ml-1 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </a>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Platform Information */}
      <div className="bg-blue-50 rounded-lg border border-blue-200">
        <div className="p-6">
          <div className="flex items-start">
            <Brain className="h-8 w-8 text-blue-600 mt-1" />
            <div className="ml-4">
              <h3 className="text-lg font-medium text-blue-900">AI-Powered Legal Analysis</h3>
              <p className="mt-2 text-blue-700">
                This platform integrates HuggingFace AI models with real legal data from Harvard's Caselaw Access Project. 
                All analysis is performed using authentic legal cases, judge behavioral patterns, and game theory calculations 
                for strategic legal intelligence.
              </p>
              <div className="mt-4 flex space-x-6 text-sm text-blue-600">
                <span>• HuggingFace AI Integration</span>
                <span>• Real Legal Data Analysis</span>
                <span>• Nash Equilibrium Calculations</span>
                <span>• Strategic Game Theory</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
