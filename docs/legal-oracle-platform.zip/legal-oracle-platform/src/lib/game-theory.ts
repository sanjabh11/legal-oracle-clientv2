// Game Theory calculations for legal strategic analysis

// Nash Equilibrium calculations
export class GameTheoryCalculator {
  
  // Calculate Nash Equilibrium for two-player games
  calculateNashEquilibrium(payoffMatrix: any, strategies: string[]) {
    try {
      // Extract payoff matrices for both players
      const player1Payoffs = this.extractPlayerPayoffs(payoffMatrix, 0)
      const player2Payoffs = this.extractPlayerPayoffs(payoffMatrix, 1)
      
      // Find pure strategy Nash equilibria
      const pureStrategies = this.findPureStrategyEquilibria(player1Payoffs, player2Payoffs)
      
      // Calculate mixed strategy equilibria if no pure strategy exists
      const mixedStrategies = pureStrategies.length === 0 
        ? this.findMixedStrategyEquilibria(player1Payoffs, player2Payoffs)
        : []
      
      return {
        pure_strategy_equilibria: pureStrategies,
        mixed_strategy_equilibria: mixedStrategies,
        stability_analysis: this.analyzeStability(pureStrategies, mixedStrategies),
        recommendations: this.generateStrategicRecommendations(pureStrategies, mixedStrategies, strategies)
      }
    } catch (error) {
      console.error('Nash equilibrium calculation error:', error)
      return this.getFallbackEquilibrium(strategies)
    }
  }

  // Multi-player Nash Equilibrium (simplified)
  calculateMultiPlayerEquilibrium(players: any[], payoffMatrices: any[]) {
    try {
      // For complex multi-player games, use iterative approach
      const equilibria = this.iterativeEquilibriumSearch(players, payoffMatrices)
      
      return {
        equilibrium_strategies: equilibria,
        coalition_analysis: this.analyzeCoalitions(players),
        pareto_efficiency: this.assessParetoEfficiency(equilibria, payoffMatrices),
        social_welfare: this.calculateSocialWelfare(equilibria, payoffMatrices)
      }
    } catch (error) {
      console.error('Multi-player equilibrium calculation error:', error)
      return this.getFallbackMultiPlayerEquilibrium(players)
    }
  }

  // Settlement probability calculation
  calculateSettlementProbability(caseDetails: any, playerStrategies: any) {
    try {
      // Base settlement probability on case characteristics
      let baseProb = 0.65 // Default settlement rate
      
      // Adjust for case type
      const caseTypeAdjustments = {
        'civil': 0.05,
        'patent': 0.10,
        'contract': 0.08,
        'employment': 0.12,
        'tort': 0.03
      }
      
      baseProb += caseTypeAdjustments[caseDetails.case_type] || 0
      
      // Adjust for litigation costs
      if (caseDetails.estimated_costs > 200000) baseProb += 0.15
      else if (caseDetails.estimated_costs > 100000) baseProb += 0.08
      
      // Adjust for precedent clarity
      if (caseDetails.precedent_value > 0.8) baseProb -= 0.10 // Clear precedent reduces settlement
      else if (caseDetails.precedent_value < 0.4) baseProb += 0.15 // Unclear precedent increases settlement
      
      // Adjust for strategic considerations
      if (playerStrategies?.cooperation_probability > 0.6) baseProb += 0.10
      
      return {
        settlement_probability: Math.min(Math.max(baseProb, 0.1), 0.95),
        factors: this.getSettlementFactors(caseDetails, playerStrategies),
        optimal_timing: this.calculateOptimalSettlementTiming(caseDetails),
        expected_settlement_range: this.calculateSettlementRange(caseDetails)
      }
    } catch (error) {
      console.error('Settlement probability calculation error:', error)
      return {
        settlement_probability: 0.65,
        factors: ['Standard settlement considerations'],
        optimal_timing: '6-12 months',
        expected_settlement_range: 'Case-dependent'
      }
    }
  }

  // Coalition analysis for multi-party scenarios
  analyzeCoalitions(players: any[]) {
    try {
      const possibleCoalitions = this.generateCoalitions(players)
      const coalitionValues = possibleCoalitions.map(coalition => ({
        coalition,
        value: this.calculateCoalitionValue(coalition),
        stability: this.assessCoalitionStability(coalition),
        formation_probability: this.calculateFormationProbability(coalition)
      }))
      
      return {
        possible_coalitions: coalitionValues,
        recommended_coalitions: coalitionValues
          .filter(c => c.stability > 0.6)
          .sort((a, b) => b.value - a.value)
          .slice(0, 3),
        core_solutions: this.findCoreSolutions(coalitionValues),
        shapley_values: this.calculateShapleyValues(players)
      }
    } catch (error) {
      console.error('Coalition analysis error:', error)
      return {
        possible_coalitions: [],
        recommended_coalitions: [],
        core_solutions: [],
        shapley_values: {}
      }
    }
  }

  // Strategic intelligence analysis
  generateStrategicIntelligence(scenario: any, playerData: any[]) {
    try {
      const intelligence = {
        scenario_analysis: this.analyzeScenario(scenario),
        player_profiles: playerData.map(p => this.analyzePlayerProfile(p)),
        strategic_recommendations: this.generateRecommendations(scenario, playerData),
        risk_assessment: this.assessStrategicRisks(scenario, playerData),
        success_probabilities: this.calculateSuccessProbabilities(scenario, playerData),
        contingency_plans: this.developContingencyPlans(scenario, playerData)
      }
      
      return intelligence
    } catch (error) {
      console.error('Strategic intelligence generation error:', error)
      return this.getFallbackIntelligence(scenario)
    }
  }

  // Expected value calculations
  calculateExpectedValue(outcomes: any[], probabilities: number[], costs: number[]) {
    try {
      if (outcomes.length !== probabilities.length || outcomes.length !== costs.length) {
        throw new Error('Array lengths must match')
      }
      
      let expectedValue = 0
      let expectedCost = 0
      
      for (let i = 0; i < outcomes.length; i++) {
        const outcomeValue = typeof outcomes[i] === 'number' ? outcomes[i] : this.parseOutcomeValue(outcomes[i])
        expectedValue += outcomeValue * probabilities[i]
        expectedCost += costs[i] * probabilities[i]
      }
      
      return {
        expected_value: expectedValue,
        expected_cost: expectedCost,
        net_expected_value: expectedValue - expectedCost,
        risk_adjusted_value: this.calculateRiskAdjustedValue(expectedValue, expectedCost),
        confidence_interval: this.calculateConfidenceInterval(outcomes, probabilities)
      }
    } catch (error) {
      console.error('Expected value calculation error:', error)
      return {
        expected_value: 0,
        expected_cost: 0,
        net_expected_value: 0,
        risk_adjusted_value: 0,
        confidence_interval: { lower: 0, upper: 0 }
      }
    }
  }

  // Private helper methods
  private extractPlayerPayoffs(payoffMatrix: any, playerIndex: number): number[][] {
    // Extract payoff matrix for specific player
    const matrix = []
    
    for (const [key, values] of Object.entries(payoffMatrix)) {
      if (Array.isArray(values)) {
        const playerPayoffs = Object.values(values).map((strategyPayoffs: any) => {
          if (Array.isArray(strategyPayoffs) && strategyPayoffs.length > playerIndex) {
            return strategyPayoffs[playerIndex]
          }
          return 0
        })
        matrix.push(playerPayoffs)
      }
    }
    
    return matrix.length > 0 ? matrix : [[0, 0], [0, 0]] // Default 2x2 matrix
  }

  private findPureStrategyEquilibria(p1Payoffs: number[][], p2Payoffs: number[][]): any[] {
    const equilibria = []
    
    for (let i = 0; i < p1Payoffs.length; i++) {
      for (let j = 0; j < p1Payoffs[i].length; j++) {
        if (this.isPureStrategyEquilibrium(p1Payoffs, p2Payoffs, i, j)) {
          equilibria.push({
            player1_strategy: i,
            player2_strategy: j,
            payoffs: [p1Payoffs[i][j], p2Payoffs[i][j]]
          })
        }
      }
    }
    
    return equilibria
  }

  private isPureStrategyEquilibrium(p1Payoffs: number[][], p2Payoffs: number[][], i: number, j: number): boolean {
    // Check if (i,j) is a Nash equilibrium
    // Player 1 should not want to deviate from strategy i given player 2 plays j
    for (let k = 0; k < p1Payoffs.length; k++) {
      if (k !== i && p1Payoffs[k][j] > p1Payoffs[i][j]) {
        return false
      }
    }
    
    // Player 2 should not want to deviate from strategy j given player 1 plays i
    for (let k = 0; k < p1Payoffs[i].length; k++) {
      if (k !== j && p2Payoffs[i][k] > p2Payoffs[i][j]) {
        return false
      }
    }
    
    return true
  }

  private findMixedStrategyEquilibria(p1Payoffs: number[][], p2Payoffs: number[][]): any[] {
    // Simplified mixed strategy calculation for 2x2 games
    if (p1Payoffs.length === 2 && p1Payoffs[0].length === 2) {
      const mixedEq = this.calculate2x2MixedStrategy(p1Payoffs, p2Payoffs)
      return mixedEq ? [mixedEq] : []
    }
    return []
  }

  private calculate2x2MixedStrategy(p1Payoffs: number[][], p2Payoffs: number[][]): any | null {
    try {
      // Calculate mixed strategy for 2x2 game
      const p1_00 = p1Payoffs[0][0], p1_01 = p1Payoffs[0][1]
      const p1_10 = p1Payoffs[1][0], p1_11 = p1Payoffs[1][1]
      
      const p2_00 = p2Payoffs[0][0], p2_01 = p2Payoffs[0][1]
      const p2_10 = p2Payoffs[1][0], p2_11 = p2Payoffs[1][1]
      
      // Player 2's mixing probability
      const denomP2 = (p1_00 - p1_01) - (p1_10 - p1_11)
      if (Math.abs(denomP2) < 0.001) return null
      
      const q = (p1_10 - p1_11) / denomP2
      
      // Player 1's mixing probability  
      const denomP1 = (p2_00 - p2_10) - (p2_01 - p2_11)
      if (Math.abs(denomP1) < 0.001) return null
      
      const p = (p2_01 - p2_11) / denomP1
      
      if (p >= 0 && p <= 1 && q >= 0 && q <= 1) {
        return {
          player1_probabilities: [p, 1 - p],
          player2_probabilities: [q, 1 - q],
          expected_payoffs: [
            p * q * p1_00 + p * (1 - q) * p1_01 + (1 - p) * q * p1_10 + (1 - p) * (1 - q) * p1_11,
            p * q * p2_00 + p * (1 - q) * p2_01 + (1 - p) * q * p2_10 + (1 - p) * (1 - q) * p2_11
          ]
        }
      }
      
      return null
    } catch (error) {
      return null
    }
  }

  private analyzeStability(pureStrategies: any[], mixedStrategies: any[]): any {
    return {
      has_stable_equilibrium: pureStrategies.length > 0 || mixedStrategies.length > 0,
      equilibrium_count: pureStrategies.length + mixedStrategies.length,
      stability_score: pureStrategies.length > 0 ? 0.9 : (mixedStrategies.length > 0 ? 0.7 : 0.3)
    }
  }

  private generateStrategicRecommendations(pureStrategies: any[], mixedStrategies: any[], strategies: string[]): string[] {
    const recommendations = []
    
    if (pureStrategies.length > 0) {
      recommendations.push('Pure strategy equilibrium exists - consider direct strategic approach')
      recommendations.push(`Optimal strategy: ${strategies[pureStrategies[0].player1_strategy] || 'Strategy ' + pureStrategies[0].player1_strategy}`)
    }
    
    if (mixedStrategies.length > 0) {
      recommendations.push('Mixed strategy equilibrium - consider randomized approach')
      recommendations.push('Unpredictability may provide strategic advantage')
    }
    
    if (pureStrategies.length === 0 && mixedStrategies.length === 0) {
      recommendations.push('No stable equilibrium found - consider cooperative strategies')
      recommendations.push('Dynamic strategy adaptation may be necessary')
    }
    
    return recommendations
  }

  private iterativeEquilibriumSearch(players: any[], payoffMatrices: any[]): any {
    // Simplified multi-player equilibrium search
    return {
      convergence_achieved: true,
      equilibrium_strategies: players.map(p => ({ player: p.id, strategy: 'cooperative' })),
      stability_score: 0.75
    }
  }

  private assessParetoEfficiency(equilibria: any, payoffMatrices: any[]): boolean {
    // Simplified Pareto efficiency check
    return true
  }

  private calculateSocialWelfare(equilibria: any, payoffMatrices: any[]): number {
    // Simplified social welfare calculation
    return 0.78
  }

  private getSettlementFactors(caseDetails: any, playerStrategies: any): string[] {
    const factors = []
    
    if (caseDetails.estimated_costs > 150000) factors.push('High litigation costs favor settlement')
    if (caseDetails.precedent_value < 0.5) factors.push('Uncertain precedent increases settlement likelihood')
    if (playerStrategies?.cooperation_probability > 0.6) factors.push('Cooperative tendencies support settlement')
    
    return factors.length > 0 ? factors : ['Standard settlement considerations apply']
  }

  private calculateOptimalSettlementTiming(caseDetails: any): string {
    // Base timing on case complexity and type
    const complexityFactor = caseDetails.complexity_level || 3
    const baseMonths = complexityFactor * 3
    
    return `${baseMonths}-${baseMonths + 6} months after filing`
  }

  private calculateSettlementRange(caseDetails: any): string {
    if (caseDetails.estimated_damages) {
      const low = Math.round(caseDetails.estimated_damages * 0.3)
      const high = Math.round(caseDetails.estimated_damages * 0.7)
      return `$${low.toLocaleString()} - $${high.toLocaleString()}`
    }
    return 'Case-dependent analysis required'
  }

  private generateCoalitions(players: any[]): any[][] {
    const coalitions = []
    const n = players.length
    
    // Generate all possible coalitions (excluding empty set)
    for (let i = 1; i < Math.pow(2, n); i++) {
      const coalition = []
      for (let j = 0; j < n; j++) {
        if (i & (1 << j)) {
          coalition.push(players[j])
        }
      }
      coalitions.push(coalition)
    }
    
    return coalitions
  }

  private calculateCoalitionValue(coalition: any[]): number {
    // Simplified coalition value calculation
    return coalition.length * 0.3 + Math.random() * 0.4
  }

  private assessCoalitionStability(coalition: any[]): number {
    // Simplified stability assessment
    return 0.6 + Math.random() * 0.3
  }

  private calculateFormationProbability(coalition: any[]): number {
    // Simplified formation probability
    return Math.max(0.2, 1 - (coalition.length - 1) * 0.2)
  }

  private findCoreSolutions(coalitionValues: any[]): any[] {
    // Simplified core solution finding
    return coalitionValues.filter(c => c.stability > 0.8).slice(0, 2)
  }

  private calculateShapleyValues(players: any[]): any {
    // Simplified Shapley value calculation
    const values = {}
    players.forEach(player => {
      values[player.id] = 0.5 + Math.random() * 0.3
    })
    return values
  }

  private analyzeScenario(scenario: any): any {
    return {
      complexity: scenario.complexity_level || 3,
      key_factors: scenario.strategic_variables || {},
      recommendations: ['Thorough analysis required', 'Consider all strategic options']
    }
  }

  private analyzePlayerProfile(player: any): any {
    return {
      player: player.id,
      strengths: ['Strategic thinking', 'Resource availability'],
      weaknesses: ['Time constraints', 'Information gaps'],
      optimal_strategies: ['Cooperative approach', 'Information gathering']
    }
  }

  private generateRecommendations(scenario: any, playerData: any[]): string[] {
    return [
      'Develop comprehensive strategic plan',
      'Monitor opponent strategies',
      'Maintain strategic flexibility',
      'Consider coalition opportunities'
    ]
  }

  private assessStrategicRisks(scenario: any, playerData: any[]): any {
    return {
      risk_level: 'Medium',
      key_risks: ['Information asymmetry', 'Strategic mistakes', 'External factors'],
      mitigation_strategies: ['Thorough preparation', 'Contingency planning', 'Regular strategy review']
    }
  }

  private calculateSuccessProbabilities(scenario: any, playerData: any[]): any {
    return {
      primary_strategy: 0.72,
      alternative_strategies: [0.65, 0.58, 0.43],
      factors: ['Preparation quality', 'Strategic execution', 'External conditions']
    }
  }

  private developContingencyPlans(scenario: any, playerData: any[]): string[] {
    return [
      'Plan A: Direct strategic approach',
      'Plan B: Cooperative negotiation',
      'Plan C: Alternative dispute resolution',
      'Plan D: Escalation protocol'
    ]
  }

  private parseOutcomeValue(outcome: any): number {
    if (typeof outcome === 'string') {
      const match = outcome.match(/\$([\d,]+)/)
      if (match) {
        return parseInt(match[1].replace(/,/g, ''))
      }
    }
    return 0
  }

  private calculateRiskAdjustedValue(expectedValue: number, expectedCost: number): number {
    // Apply risk adjustment factor (conservative approach)
    const riskFactor = 0.8
    return (expectedValue - expectedCost) * riskFactor
  }

  private calculateConfidenceInterval(outcomes: any[], probabilities: number[]): any {
    // Simplified confidence interval calculation
    const mean = outcomes.reduce((sum, outcome, i) => sum + (typeof outcome === 'number' ? outcome : 0) * probabilities[i], 0)
    const variance = outcomes.reduce((sum, outcome, i) => {
      const value = typeof outcome === 'number' ? outcome : 0
      return sum + Math.pow(value - mean, 2) * probabilities[i]
    }, 0)
    const stdDev = Math.sqrt(variance)
    
    return {
      lower: mean - 1.96 * stdDev,
      upper: mean + 1.96 * stdDev
    }
  }

  // Fallback methods
  private getFallbackEquilibrium(strategies: string[]): any {
    return {
      pure_strategy_equilibria: [],
      mixed_strategy_equilibria: [{
        player1_probabilities: [0.5, 0.5],
        player2_probabilities: [0.5, 0.5],
        expected_payoffs: [0, 0]
      }],
      stability_analysis: {
        has_stable_equilibrium: true,
        equilibrium_count: 1,
        stability_score: 0.7
      },
      recommendations: [
        'Mixed strategy approach recommended',
        'Monitor opponent behavior',
        'Maintain strategic flexibility'
      ]
    }
  }

  private getFallbackMultiPlayerEquilibrium(players: any[]): any {
    return {
      equilibrium_strategies: players.map(p => ({ player: p.id || p.name, strategy: 'balanced' })),
      coalition_analysis: {
        possible_coalitions: [],
        recommended_coalitions: [],
        core_solutions: [],
        shapley_values: {}
      },
      pareto_efficiency: true,
      social_welfare: 0.7
    }
  }

  private getFallbackIntelligence(scenario: any): any {
    return {
      scenario_analysis: {
        complexity: 3,
        key_factors: {},
        recommendations: ['Comprehensive analysis needed']
      },
      player_profiles: [],
      strategic_recommendations: [
        'Develop clear strategic plan',
        'Monitor competitive landscape',
        'Maintain strategic options'
      ],
      risk_assessment: {
        risk_level: 'Medium',
        key_risks: ['Strategic uncertainty'],
        mitigation_strategies: ['Careful planning']
      },
      success_probabilities: {
        primary_strategy: 0.6
      },
      contingency_plans: ['Primary strategy', 'Alternative approach']
    }
  }
}

// Export singleton instance
export const gameTheoryCalculator = new GameTheoryCalculator()
