import React from 'react'
import { NavLink } from 'react-router-dom'
import { 
  BarChart3, 
  FileSearch, 
  Gavel, 
  TrendingUp, 
  Target, 
  FileText, 
  Users, 
  GitBranch, 
  Shield, 
  HandShake, 
  MessageSquare, 
  Brain,
  BookOpen
} from 'lucide-react'

const Sidebar: React.FC = () => {
  const navigation = [
    {
      name: 'Dashboard',
      href: '/',
      icon: BarChart3,
      description: 'Overview & Analytics'
    },
    {
      name: 'Case Outcome Prediction',
      href: '/predict-outcome',
      icon: Target,
      description: 'AI-Powered Predictions'
    },
    {
      name: 'Caselaw Search',
      href: '/caselaw-search',
      icon: FileSearch,
      description: 'Legal Precedent Discovery'
    },
    {
      name: 'Judge Behavior Analysis',
      href: '/judge-analysis',
      icon: Gavel,
      description: 'Judicial Pattern Analysis'
    },
    {
      name: 'Legal Trend Forecasting',
      href: '/trend-forecasting',
      icon: TrendingUp,
      description: 'Predictive Trend Analysis'
    },
    {
      name: 'Strategy Optimization',
      href: '/strategy-optimization',
      icon: Shield,
      description: 'Strategic Legal Planning'
    },
    {
      name: 'Similar Case Finder',
      href: '/similar-cases',
      icon: BookOpen,
      description: 'Precedent Matching'
    },
    {
      name: 'Document Analysis',
      href: '/document-analysis',
      icon: FileText,
      description: 'AI Document Processing'
    },
    {
      name: 'Multi-Player Scenarios',
      href: '/multiplayer-scenarios',
      icon: Users,
      description: 'Strategic Game Modeling'
    },
    {
      name: 'Nash Equilibrium',
      href: '/nash-equilibrium',
      icon: GitBranch,
      description: 'Game Theory Analysis'
    },
    {
      name: 'Coalition Analysis',
      href: '/coalition-analysis',
      icon: Users,
      description: 'Multi-Party Strategy'
    },
    {
      name: 'Settlement Analysis',
      href: '/settlement-analysis',
      icon: HandShake,
      description: 'Settlement Probability'
    },
    {
      name: 'Negotiation Modeling',
      href: '/negotiation-modeling',
      icon: MessageSquare,
      description: 'Negotiation Strategy'
    },
    {
      name: 'Strategic Intelligence',
      href: '/strategic-intelligence',
      icon: Brain,
      description: 'AI Strategic Insights'
    }
  ]

  return (
    <div className="fixed inset-y-0 left-0 w-64 bg-slate-800 shadow-xl">
      <div className="flex flex-col h-full">
        {/* Navigation Header */}
        <div className="p-4 border-b border-slate-700">
          <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
            Legal Intelligence Suite
          </h2>
        </div>
        
        {/* Navigation Menu */}
        <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
          {navigation.map((item) => {
            const Icon = item.icon
            return (
              <NavLink
                key={item.name}
                to={item.href}
                className={({ isActive }) =>
                  `group flex flex-col rounded-lg p-3 text-sm font-medium transition-all duration-200 ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-lg'
                      : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                  }`
                }
              >
                <div className="flex items-center space-x-3">
                  <Icon className="h-5 w-5 flex-shrink-0" />
                  <span className="truncate">{item.name}</span>
                </div>
                <p className="text-xs text-slate-400 group-hover:text-slate-300 mt-1 ml-8 truncate">
                  {item.description}
                </p>
              </NavLink>
            )
          })}
        </nav>
        
        {/* Footer */}
        <div className="p-4 border-t border-slate-700">
          <div className="flex items-center justify-center space-x-2 text-slate-400">
            <Brain className="h-4 w-4" />
            <span className="text-xs font-medium">Powered by AI & Game Theory</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Sidebar
