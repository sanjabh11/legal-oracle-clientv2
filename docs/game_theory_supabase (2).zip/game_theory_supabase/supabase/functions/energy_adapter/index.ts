// energy_adapter/index.ts
// Universal Canadian Energy Data Adapter - Production Grade
// Handles 7 major Canadian energy data sources with robust parsing

import { serve } from "https://deno.land/std@0.192.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const sb = createClient(SUPABASE_URL, SERVICE_KEY, { auth: { persistSession: false } });

// Complete SOURCES mapping for all 7 Canadian energy data sources
const SOURCES: Record<string, {
  url: string;
  parser: (raw: string) => Array<Record<string, any>>;
  normalize: (row: Record<string, any>) => Record<string, any> | null;
}> = {

  // IESO (Ontario) - CSV-based realtime reports (keeps previous logic)
  ieso: {
    url: Deno.env.get("IESO_PRIMARY_URL") ?? Deno.env.get("IESO_API_URL") ?? "",
    parser: (raw) => {
      // CSV parse: header row -> objects
      const lines = raw.trim().split(/\r?\n/).filter(Boolean);
      if (lines.length < 2) return [];
      const headers = lines[0].split(",").map(h => h.trim());
      return lines.slice(1).map(line => {
        const cols = line.split(",");
        const obj: any = {};
        headers.forEach((h,i) => obj[h] = (cols[i] ?? "").trim());
        return obj;
      });
    },
    normalize: (r) => {
      // try multiple header names
      const ts = r["Report_dt"] || r["Timestamp"] || r["Time"] || r["DateTime"] || r["Hour"];
      const rawVal = r["Ontario Demand (MW)"] || r["Ontario Demand"] || r["Demand (MW)"] || r["ONTARIO_DEMAND"];
      if (!ts || !rawVal) return null;
      const v = Number(String(rawVal).replace(/[^0-9.\-]/g,""));
      if (!Number.isFinite(v)) return null;
      return {
        source: "ieso",
        metric: "demand",
        ts: new Date(ts).toISOString(),
        value: v,                    // MW
        region: Deno.env.get("REGION_ON") || "Ontario",
        consent_tag: "public"
      };
    }
  },

  // AESO (Alberta) - JSON endpoint
  aeso: {
    url: Deno.env.get("AESO_URL") ?? "",
    parser: (raw) => {
      try { const j = JSON.parse(raw); return Array.isArray(j.data) ? j.data : (Array.isArray(j) ? j : (j?.records || [])); }
      catch(e){ return []; }
    },
    normalize: (r) => {
      const ts = r["publishTime"] || r["publishingDate"] || r["begin_datetime_mpt"] || r["timestamp"];
      const load = r["currentSystemLoad"] ?? r["total_demand"] ?? r["load"];
      const price = r["poolPrice"] ?? r["price"];
      const out: any[] = [];
      if (ts && load != null) {
        const v = Number(String(load).replace(/[^0-9.\-]/g,""));
        if (Number.isFinite(v)) out.push({ source: "aeso", metric: "demand", ts: new Date(ts).toISOString(), value: v, region: Deno.env.get("REGION_AB") || "Alberta", consent_tag: "public" });
      }
      if (ts && price != null) {
        const p = Number(String(price).replace(/[^0-9.\-]/g,""));
        if (Number.isFinite(p)) out.push({ source: "aeso", metric: "price", ts: new Date(ts).toISOString(), value: p, region: Deno.env.get("REGION_AB") || "Alberta", consent_tag: "public" });
      }
      // return first matching row (adapter layer will insert array handling)
      return out.length ? out[0] : null;
    }
  },

  // CER — national bulk datasets (JSON or CSV)
  cer: {
    url: Deno.env.get("CER_API_URL") ?? "",
    parser: (raw) => {
      try { const j = JSON.parse(raw); return Array.isArray(j) ? j : (j.records || j.data || []); } catch(e) {
        // CSV fallback
        const lines = raw.trim().split(/\r?\n/).filter(Boolean);
        if (lines.length < 2) return [];
        const headers = lines[0].split(",").map(h=>h.trim());
        return lines.slice(1).map(l => {
          const cols = l.split(",");
          const obj: any = {};
          headers.forEach((hh,i)=> obj[hh]=cols[i]??"");
          return obj;
        });
      }
    },
    normalize: (r) => {
      const ts = r.timestamp || r.date || r["Date"];
      const val = r.value || r.production || r.amount;
      if (!ts || val == null) return null;
      return {
        source: "cer",
        metric: r.metric || r.type || "production",
        ts: new Date(ts).toISOString(),
        value: Number(String(val).replace(/[^0-9.\-]/g,"")),
        region: Deno.env.get("REGION_CA") || "Canada",
        consent_tag: "public"
      };
    }
  },

  // BC Hydro — CSV / table reports
  bchydro: {
    url: Deno.env.get("BCHYDRO_API_URL") ?? "",
    parser: (raw) => {
      const lines = raw.trim().split(/\r?\n/).filter(Boolean);
      if (lines.length < 2) return [];
      const headers = lines[0].split(",").map(h=>h.trim());
      return lines.slice(1).map(l => {
        const cols = l.split(",");
        const obj: any = {};
        headers.forEach((hh,i) => obj[hh] = cols[i] ?? "");
        return obj;
      });
    },
    normalize: (r) => {
      const ts = r["DateTime"] || r["Timestamp"] || r["time"];
      const val = r["Demand_MW"] || r["Load_MW"] || r["Demand (MW)"];
      if (!ts || val == null) return null;
      return { source: "bchydro", metric: "demand", ts: new Date(ts).toISOString(), value: Number(String(val).replace(/[^0-9.\-]/g,"")), region: Deno.env.get("REGION_BC") || "British Columbia", consent_tag: "public" };
    }
  },

  // Hydro-Québec
  hydroquebec: {
    url: Deno.env.get("HYDROQ_API_URL") ?? "",
    parser: (raw) => {
      try { const j = JSON.parse(raw); return Array.isArray(j) ? j : (j.data || []); } catch(e) {
        const lines = raw.trim().split(/\r?\n/).filter(Boolean);
        if (lines.length < 2) return [];
        const headers = lines[0].split(",").map(h=>h.trim());
        return lines.slice(1).map(l => {
          const cols = l.split(",");
          const obj: any = {};
          headers.forEach((hh,i)=> obj[hh] = cols[i] ?? "");
          return obj;
        });
      }
    },
    normalize: (r) => {
      const ts = r.timestamp || r["DateTime"] || r.time;
      const v = r.value || r.load || r["Demand_MW"];
      if (!ts || v == null) return null;
      return { source: "hydroquebec", metric: "demand", ts: new Date(ts).toISOString(), value: Number(String(v).replace(/[^0-9.\-]/g,"")), region: Deno.env.get("REGION_QC") || "Quebec", consent_tag: "public" };
    }
  },

  // Manitoba Hydro
  manitoba: {
    url: Deno.env.get("MANITOBA_API_URL") ?? "",
    parser: (raw) => { try { const j = JSON.parse(raw); return Array.isArray(j) ? j : (j.data || []); } catch(e){ return []; } },
    normalize: (r) => {
      const ts = r.timestamp || r.date;
      const v = r.load || r.value;
      if (!ts || v == null) return null;
      return { source: "manitoba", metric: "demand", ts: new Date(ts).toISOString(), value: Number(String(v).replace(/[^0-9.\-]/g,"")), region: "Manitoba", consent_tag: "public" };
    }
  },

  // SaskPower
  saskpower: {
    url: Deno.env.get("SASKPOWER_API_URL") ?? "",
    parser: (raw) => { try { const j = JSON.parse(raw); return Array.isArray(j) ? j : (j.data || []); } catch(e){ return []; } },
    normalize: (r) => {
      const ts = r.timestamp || r.time;
      const v = r.value || r.demand;
      if (!ts || v == null) return null;
      return { source: "saskpower", metric: "demand", ts: new Date(ts).toISOString(), value: Number(String(v).replace(/[^0-9.\-]/g,"")), region: "Saskatchewan", consent_tag: "public" };
    }
  }

}; // end SOURCES

// Utility functions
function secsSince(ts?: string | null) {
  if (!ts) return Number.POSITIVE_INFINITY;
  const then = new Date(ts).getTime();
  return (Date.now() - then) / 1000;
}

async function fetchWithRetry(url: string, maxRetries = 3, timeoutMs = 10000): Promise<string> {
  let lastError;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'User-Agent': 'Canadian-Energy-Intelligence-Platform/1.0',
          'Accept': 'text/csv, application/json, text/plain',
        },
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      return await response.text();
    } catch (error) {
      lastError = error;
      console.warn(`Fetch attempt ${attempt}/${maxRetries} failed:`, error);
      
      if (attempt < maxRetries) {
        // Exponential backoff: 1s, 2s, 4s...
        const delayMs = Math.pow(2, attempt - 1) * 1000;
        await new Promise(resolve => setTimeout(resolve, delayMs));
      }
    }
  }
  
  throw lastError;
}

async function updateIngestStatus(
  source: string, 
  success: boolean, 
  error?: string, 
  lastRowTs?: string,
  etag?: string,
  lastModified?: string
) {
  const now = new Date().toISOString();
  const statusUpdate: any = {
    source,
    updated_at: now
  };
  
  if (success) {
    statusUpdate.last_success_at = now;
    if (lastRowTs) statusUpdate.last_row_ts = lastRowTs;
    if (etag) statusUpdate.last_etag = etag;
    if (lastModified) statusUpdate.last_modified = lastModified;
  } else {
    statusUpdate.last_error_at = now;
    statusUpdate.last_error = error || 'Unknown error';
  }
  
  const { error: upsertError } = await sb
    .from("ingest_status")
    .upsert(statusUpdate, { onConflict: "source" });
    
  if (upsertError) {
    console.error("Failed to update ingest_status:", upsertError);
  }
}

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const sourceKey = url.searchParams.get("source");
    
    if (!sourceKey) {
      return new Response(JSON.stringify({ 
        error: "Missing 'source' parameter. Available sources: " + Object.keys(SOURCES).join(", ") 
      }), { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }
    
    const sourceConfig = SOURCES[sourceKey];
    if (!sourceConfig) {
      return new Response(JSON.stringify({ 
        error: `Unknown source '${sourceKey}'. Available sources: ${Object.keys(SOURCES).join(", ")}` 
      }), { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }
    
    if (!sourceConfig.url) {
      await updateIngestStatus(sourceKey, false, `No URL configured for source ${sourceKey}`);
      return new Response(JSON.stringify({ 
        error: `No URL configured for source ${sourceKey}. Please set environment variable.` 
      }), { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }

    console.log(`Starting ingestion for source: ${sourceKey}`);
    console.log(`Fetching from URL: ${sourceConfig.url}`);
    
    // Fetch data with retry logic
    let rawData: string;
    try {
      rawData = await fetchWithRetry(sourceConfig.url);
    } catch (fetchError) {
      const errorMsg = `Failed to fetch data from ${sourceKey}: ${fetchError}`;
      console.error(errorMsg);
      await updateIngestStatus(sourceKey, false, errorMsg);
      return new Response(JSON.stringify({ 
        error: errorMsg,
        source: sourceKey
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }
    
    if (!rawData || rawData.trim().length === 0) {
      const errorMsg = `Empty response from ${sourceKey}`;
      await updateIngestStatus(sourceKey, false, errorMsg);
      return new Response(JSON.stringify({ 
        error: errorMsg,
        source: sourceKey
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }

    // Parse raw data
    let parsedData: Array<Record<string, any>>;
    try {
      parsedData = sourceConfig.parser(rawData);
    } catch (parseError) {
      const errorMsg = `Failed to parse data from ${sourceKey}: ${parseError}`;
      console.error(errorMsg);
      await updateIngestStatus(sourceKey, false, errorMsg);
      return new Response(JSON.stringify({ 
        error: errorMsg,
        source: sourceKey
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }
    
    if (!parsedData || parsedData.length === 0) {
      const errorMsg = `No parseable data from ${sourceKey}`;
      await updateIngestStatus(sourceKey, false, errorMsg);
      return new Response(JSON.stringify({ 
        error: errorMsg,
        source: sourceKey,
        raw_sample: rawData.substring(0, 200)
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }

    // Normalize and filter data
    const normalizedEvents: Array<Record<string, any>> = [];
    let lastRowTs: string | undefined;
    
    for (const row of parsedData) {
      try {
        const normalized = sourceConfig.normalize(row);
        if (normalized) {
          normalizedEvents.push(normalized);
          // Track latest timestamp for status update
          if (normalized.ts) {
            if (!lastRowTs || new Date(normalized.ts) > new Date(lastRowTs)) {
              lastRowTs = normalized.ts;
            }
          }
        }
      } catch (normalizeError) {
        console.warn(`Failed to normalize row for ${sourceKey}:`, normalizeError, row);
      }
    }
    
    if (normalizedEvents.length === 0) {
      const errorMsg = `No normalizable events from ${sourceKey}`;
      await updateIngestStatus(sourceKey, false, errorMsg);
      return new Response(JSON.stringify({ 
        error: errorMsg,
        source: sourceKey,
        parsed_count: parsedData.length,
        sample_row: parsedData[0]
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }

    // Insert events into database with deduplication
    let insertedCount = 0;
    try {
      const { error: insertError, count } = await sb
        .from("energy_events")
        .upsert(normalizedEvents, { 
          onConflict: "source, metric, ts, region",
          ignoreDuplicates: true
        })
        .select("*", { count: "exact" });
      
      if (insertError) {
        throw insertError;
      }
      
      insertedCount = count || 0;
    } catch (insertError) {
      const errorMsg = `Failed to insert events for ${sourceKey}: ${insertError}`;
      console.error(errorMsg);
      await updateIngestStatus(sourceKey, false, errorMsg);
      return new Response(JSON.stringify({ 
        error: errorMsg,
        source: sourceKey
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }
    
    // Update ingest status with success
    await updateIngestStatus(sourceKey, true, undefined, lastRowTs);
    
    const result = {
      success: true,
      source: sourceKey,
      fetched_bytes: rawData.length,
      parsed_rows: parsedData.length,
      normalized_events: normalizedEvents.length,
      inserted_count: insertedCount,
      last_row_ts: lastRowTs,
      sample_event: normalizedEvents[0]
    };
    
    console.log(`Successfully processed ${sourceKey}:`, result);
    
    return new Response(JSON.stringify(result), { 
      status: 200, 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
    });
    
  } catch (err) {
    console.error("Unexpected error in energy_adapter:", err);
    return new Response(JSON.stringify({ 
      error: `Unexpected error: ${err}` 
    }), { 
      status: 500, 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
    });
  }
});
