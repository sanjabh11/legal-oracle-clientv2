import React, { useState } from 'react'
import { useLegalOracle } from '../contexts/LegalOracleContext'
import { Target, Brain, TrendingUp, AlertCircle, CheckCircle, Loader } from 'lucide-react'
import { toast } from 'sonner'

const CaseOutcomePrediction: React.FC = () => {
  const { cases, loading, analysisResults, predictOutcome } = useLegalOracle()
  const [selectedCase, setSelectedCase] = useState<any>(null)
  const [customCase, setCustomCase] = useState({
    case_name: '',
    case_type: 'civil',
    jurisdiction: 'federal',
    summary: '',
    legal_issues: []
  })
  const [useCustomCase, setUseCustomCase] = useState(false)
  const [analyzing, setAnalyzing] = useState(false)

  const handlePredictOutcome = async () => {
    const caseData = useCustomCase ? customCase : selectedCase
    
    if (!caseData || (!caseData.summary && !caseData.case_description)) {
      toast.error('Please provide case details for analysis')
      return
    }

    setAnalyzing(true)
    try {
      await predictOutcome(caseData)
      toast.success('Case outcome prediction completed')
    } catch (error) {
      console.error('Prediction failed:', error)
    } finally {
      setAnalyzing(false)
    }
  }

  const prediction = analysisResults.outcome_prediction

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900 flex items-center">
          <Target className="h-8 w-8 text-blue-600 mr-3" />
          Case Outcome Prediction
        </h1>
        <p className="mt-2 text-lg text-slate-600">
          AI-powered analysis using HuggingFace models to predict legal case outcomes
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <div className="space-y-6">
          {/* Case Selection */}
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-medium text-slate-900 mb-4">Select Case for Analysis</h3>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <input
                  type="radio"
                  id="existing-case"
                  name="case-source"
                  checked={!useCustomCase}
                  onChange={() => setUseCustomCase(false)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300"
                />
                <label htmlFor="existing-case" className="text-sm font-medium text-slate-700">
                  Use Existing Legal Case
                </label>
              </div>
              
              {!useCustomCase && (
                <select
                  value={selectedCase?.id || ''}
                  onChange={(e) => {
                    const case_ = cases.find(c => c.id === e.target.value)
                    setSelectedCase(case_)
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select a legal case...</option>
                  {cases.map((case_) => (
                    <option key={case_.id} value={case_.id}>
                      {case_.case_name} ({case_.case_type} - {case_.jurisdiction})
                    </option>
                  ))}
                </select>
              )}
              
              <div className="flex items-center space-x-3">
                <input
                  type="radio"
                  id="custom-case"
                  name="case-source"
                  checked={useCustomCase}
                  onChange={() => setUseCustomCase(true)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300"
                />
                <label htmlFor="custom-case" className="text-sm font-medium text-slate-700">
                  Enter Custom Case Details
                </label>
              </div>
            </div>
          </div>

          {/* Custom Case Input */}
          {useCustomCase && (
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
              <h3 className="text-lg font-medium text-slate-900 mb-4">Case Details</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700">Case Name</label>
                  <input
                    type="text"
                    value={customCase.case_name}
                    onChange={(e) => setCustomCase(prev => ({ ...prev, case_name: e.target.value }))}
                    className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter case name..."
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Case Type</label>
                    <select
                      value={customCase.case_type}
                      onChange={(e) => setCustomCase(prev => ({ ...prev, case_type: e.target.value }))}
                      className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="civil">Civil</option>
                      <option value="criminal">Criminal</option>
                      <option value="regulatory">Regulatory</option>
                      <option value="corporate">Corporate</option>
                      <option value="ip">Intellectual Property</option>
                      <option value="employment">Employment</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Jurisdiction</label>
                    <select
                      value={customCase.jurisdiction}
                      onChange={(e) => setCustomCase(prev => ({ ...prev, jurisdiction: e.target.value }))}
                      className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="federal">Federal</option>
                      <option value="state">State</option>
                      <option value="local">Local</option>
                    </select>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700">Case Summary</label>
                  <textarea
                    value={customCase.summary}
                    onChange={(e) => setCustomCase(prev => ({ ...prev, summary: e.target.value }))}
                    rows={4}
                    className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter detailed case description and key facts..."
                  />
                </div>
              </div>
            </div>
          )}

          {/* Selected Case Display */}
          {!useCustomCase && selectedCase && (
            <div className="bg-slate-50 rounded-lg border border-slate-200 p-6">
              <h3 className="text-lg font-medium text-slate-900 mb-3">{selectedCase.case_name}</h3>
              <div className="space-y-2 text-sm">
                <p><span className="font-medium">Type:</span> {selectedCase.case_type}</p>
                <p><span className="font-medium">Jurisdiction:</span> {selectedCase.jurisdiction}</p>
                <p><span className="font-medium">Summary:</span> {selectedCase.summary}</p>
                {selectedCase.legal_issues && selectedCase.legal_issues.length > 0 && (
                  <p><span className="font-medium">Legal Issues:</span> {selectedCase.legal_issues.join(', ')}</p>
                )}
              </div>
            </div>
          )}

          {/* Analysis Button */}
          <button
            onClick={handlePredictOutcome}
            disabled={analyzing || (!selectedCase && !useCustomCase) || (useCustomCase && !customCase.summary)}
            className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 disabled:bg-slate-400 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {analyzing ? (
              <>
                <Loader className="animate-spin h-5 w-5 mr-2" />
                Analyzing Case...
              </>
            ) : (
              <>
                <Brain className="h-5 w-5 mr-2" />
                Predict Case Outcome
              </>
            )}
          </button>
        </div>

        {/* Results Section */}
        <div className="space-y-6">
          {prediction ? (
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
              <div className="flex items-center mb-4">
                <CheckCircle className="h-6 w-6 text-green-600 mr-2" />
                <h3 className="text-lg font-medium text-slate-900">AI Analysis Results</h3>
              </div>
              
              <div className="space-y-4">
                {/* Prediction */}
                <div>
                  <h4 className="text-sm font-medium text-slate-500 mb-2">Predicted Outcome</h4>
                  <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                    prediction.prediction === 'Favorable' ? 'bg-green-100 text-green-800' :
                    prediction.prediction === 'Unfavorable' ? 'bg-red-100 text-red-800' :
                    'bg-yellow-100 text-yellow-800'
                  }`}>
                    {prediction.prediction}
                  </div>
                </div>
                
                {/* Confidence */}
                <div>
                  <h4 className="text-sm font-medium text-slate-500 mb-2">Confidence Score</h4>
                  <div className="flex items-center">
                    <div className="flex-1 bg-slate-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${(prediction.confidence || 0) * 100}%` }}
                      />
                    </div>
                    <span className="ml-2 text-sm font-medium text-slate-900">
                      {Math.round((prediction.confidence || 0) * 100)}%
                    </span>
                  </div>
                </div>
                
                {/* Reasoning */}
                {prediction.reasoning && (
                  <div>
                    <h4 className="text-sm font-medium text-slate-500 mb-2">Key Reasoning Factors</h4>
                    <ul className="list-disc list-inside space-y-1 text-sm text-slate-700">
                      {prediction.reasoning.map((reason: string, index: number) => (
                        <li key={index}>{reason}</li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {/* Precedent Factors */}
                {prediction.precedent_factors && (
                  <div>
                    <h4 className="text-sm font-medium text-slate-500 mb-2">Precedent Factors</h4>
                    <ul className="list-disc list-inside space-y-1 text-sm text-slate-700">
                      {prediction.precedent_factors.map((factor: string, index: number) => (
                        <li key={index}>{factor}</li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {/* Risk Assessment */}
                <div>
                  <h4 className="text-sm font-medium text-slate-500 mb-2">Risk Assessment</h4>
                  <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                    prediction.risk_assessment === 'Low' ? 'bg-green-100 text-green-800' :
                    prediction.risk_assessment === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {prediction.risk_assessment} Risk
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 rounded-lg border border-slate-200 p-8 text-center">
              <TrendingUp className="h-12 w-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-500 mb-2">No Analysis Yet</h3>
              <p className="text-slate-400">
                Select a case and click "Predict Case Outcome" to see AI-powered analysis results
              </p>
            </div>
          )}
          
          {/* AI Information */}
          <div className="bg-blue-50 rounded-lg border border-blue-200 p-6">
            <div className="flex items-start">
              <Brain className="h-6 w-6 text-blue-600 mt-1" />
              <div className="ml-3">
                <h3 className="text-sm font-medium text-blue-900">AI-Powered Analysis</h3>
                <p className="mt-1 text-sm text-blue-700">
                  This analysis uses HuggingFace AI models trained on legal data to predict case outcomes. 
                  The system analyzes case facts, legal precedents, and judicial patterns to provide 
                  strategic insights.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default CaseOutcomePrediction
