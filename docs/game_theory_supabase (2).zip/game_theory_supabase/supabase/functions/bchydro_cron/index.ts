// BC Hydro Cron Function - calls main energy_adapter with source=bchydro
import { serve } from "https://deno.land/std@0.192.0/http/server.ts";

serve(async (req) => {
  try {
    // Call main energy_adapter function with source parameter
    const response = await fetch(
      `${Deno.env.get("SUPABASE_URL")}/functions/v1/energy_adapter?source=bchydro`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({}),
      }
    );

    const result = await response.json();
    
    return new Response(JSON.stringify({
      success: response.ok,
      source: 'bchydro',
      result: result
    }), {
      headers: { 'Content-Type': 'application/json' },
      status: response.ok ? 200 : 500
    });

  } catch (error) {
    return new Response(JSON.stringify({
      success: false,
      source: 'bchydro',
      error: error.message
    }), {
      headers: { 'Content-Type': 'application/json' },
      status: 500
    });
  }
});