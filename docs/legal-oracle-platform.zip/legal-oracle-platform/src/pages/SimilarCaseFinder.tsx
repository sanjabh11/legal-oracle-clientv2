import React, { useState } from 'react'
import { useLegalOracle } from '../contexts/LegalOracleContext'
import { BookOpen, Search, Target, BarChart3, Scale, ExternalLink, Loader } from 'lucide-react'
import { toast } from 'sonner'

const SimilarCaseFinder: React.FC = () => {
  const { caselaw, findSimilarCases, analysisResults } = useLegalOracle()
  const [searchCase, setSearchCase] = useState({
    case_text: '',
    legal_issues: [] as string[],
    case_type: 'civil',
    jurisdiction: 'federal'
  })
  const [newIssue, setNewIssue] = useState('')
  const [isSearching, setIsSearching] = useState(false)
  const [similarityThreshold, setSimilarityThreshold] = useState(0.3)

  const handleAddLegalIssue = () => {
    if (newIssue.trim() && !searchCase.legal_issues.includes(newIssue.trim())) {
      setSearchCase(prev => ({ 
        ...prev, 
        legal_issues: [...prev.legal_issues, newIssue.trim()] 
      }))
      setNewIssue('')
    }
  }

  const handleRemoveLegalIssue = (issueToRemove: string) => {
    setSearchCase(prev => ({
      ...prev,
      legal_issues: prev.legal_issues.filter(issue => issue !== issueToRemove)
    }))
  }

  const handleFindSimilarCases = async () => {
    if (!searchCase.case_text.trim()) {
      toast.error('Please enter case details to find similar cases')
      return
    }

    setIsSearching(true)
    try {
      await findSimilarCases(searchCase.case_text, searchCase.legal_issues)
      toast.success('Similar case analysis completed')
    } catch (error) {
      console.error('Similar case search failed:', error)
    } finally {
      setIsSearching(false)
    }
  }

  const similarCases = analysisResults.similar_cases || []
  const filteredSimilarCases = similarCases.filter(
    (similarCase: any) => (similarCase.similarity_score || 0) >= similarityThreshold
  )

  const getSimilarityColor = (score: number) => {
    if (score >= 0.8) return 'bg-green-500'
    if (score >= 0.6) return 'bg-yellow-500'
    if (score >= 0.4) return 'bg-orange-500'
    return 'bg-red-500'
  }

  const getSimilarityLabel = (score: number) => {
    if (score >= 0.8) return 'Very High'
    if (score >= 0.6) return 'High' 
    if (score >= 0.4) return 'Medium'
    return 'Low'
  }

  const formatPrecedentStrength = (strength: number) => {
    if (strength >= 0.8) return 'Strong Precedent'
    if (strength >= 0.6) return 'Moderate Precedent'
    return 'Weak Precedent'
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900 flex items-center">
          <BookOpen className="h-8 w-8 text-blue-600 mr-3" />
          Similar Case Finder
        </h1>
        <p className="mt-2 text-lg text-slate-600">
          Find similar legal cases and precedents using AI-powered case matching
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <div className="space-y-6">
          {/* Case Input */}
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-medium text-slate-900 mb-4">Case Details for Matching</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Case Description</label>
                <textarea
                  value={searchCase.case_text}
                  onChange={(e) => setSearchCase(prev => ({ ...prev, case_text: e.target.value }))}
                  rows={6}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter detailed case description, facts, and circumstances to find similar cases..."
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Case Type</label>
                  <select
                    value={searchCase.case_type}
                    onChange={(e) => setSearchCase(prev => ({ ...prev, case_type: e.target.value }))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="civil">Civil</option>
                    <option value="criminal">Criminal</option>
                    <option value="corporate">Corporate</option>
                    <option value="ip">Intellectual Property</option>
                    <option value="employment">Employment</option>
                    <option value="regulatory">Regulatory</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Jurisdiction</label>
                  <select
                    value={searchCase.jurisdiction}
                    onChange={(e) => setSearchCase(prev => ({ ...prev, jurisdiction: e.target.value }))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="federal">Federal</option>
                    <option value="state">State</option>
                    <option value="local">Local</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Legal Issues */}
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-medium text-slate-900 mb-4">Legal Issues</h3>
            
            <div className="space-y-4">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={newIssue}
                  onChange={(e) => setNewIssue(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAddLegalIssue()}
                  className="flex-1 px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Add legal issue (e.g., contract breach, negligence)"
                />
                <button
                  onClick={handleAddLegalIssue}
                  className="bg-slate-600 text-white px-4 py-2 rounded-md font-medium hover:bg-slate-700"
                >
                  Add
                </button>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {searchCase.legal_issues.map((issue, index) => (
                  <span 
                    key={index}
                    className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium flex items-center"
                  >
                    {issue}
                    <button 
                      onClick={() => handleRemoveLegalIssue(issue)}
                      className="ml-2 text-blue-600 hover:text-blue-800"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
              
              {searchCase.legal_issues.length === 0 && (
                <p className="text-sm text-slate-500 italic">
                  Add legal issues to improve matching accuracy
                </p>
              )}
            </div>
          </div>

          {/* Search Controls */}
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-medium text-slate-900 mb-4">Search Parameters</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Similarity Threshold: {Math.round(similarityThreshold * 100)}%
                </label>
                <input
                  type="range"
                  min="0.1"
                  max="0.9"
                  step="0.1"
                  value={similarityThreshold}
                  onChange={(e) => setSimilarityThreshold(parseFloat(e.target.value))}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-slate-500 mt-1">
                  <span>Broader Results</span>
                  <span>More Precise</span>
                </div>
              </div>
              
              <button
                onClick={handleFindSimilarCases}
                disabled={isSearching || !searchCase.case_text.trim()}
                className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 disabled:bg-slate-400 flex items-center justify-center"
              >
                {isSearching ? (
                  <>
                    <Loader className="animate-spin h-5 w-5 mr-2" />
                    Finding Similar Cases...
                  </>
                ) : (
                  <>
                    <Search className="h-5 w-5 mr-2" />
                    Find Similar Cases
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Results Section */}
        <div className="space-y-6">
          {filteredSimilarCases.length > 0 ? (
            <>
              {/* Results Summary */}
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium text-slate-900">Similar Cases Found</h3>
                  <div className="text-sm text-slate-500">
                    {filteredSimilarCases.length} cases match your criteria
                  </div>
                </div>
                
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center">
                    <BarChart3 className="h-4 w-4 text-slate-500 mr-1" />
                    <span className="text-slate-600">Avg. Similarity: </span>
                    <span className="font-medium text-slate-900">
                      {Math.round(filteredSimilarCases.reduce((acc: number, c: any) => acc + (c.similarity_score || 0), 0) / filteredSimilarCases.length * 100)}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Similar Cases List */}
              <div className="space-y-4">
                {filteredSimilarCases.map((similarCase: any, index: number) => {
                  const case_ = similarCase.case || {}
                  const similarityScore = similarCase.similarity_score || 0
                  
                  return (
                    <div key={index} className="bg-white rounded-lg shadow-sm border border-slate-200 p-6 hover:shadow-md transition-shadow">
                      <div className="space-y-4">
                        {/* Case Header */}
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="text-lg font-semibold text-slate-900">
                              {case_.case_title || `Similar Case ${index + 1}`}
                            </h4>
                            <div className="flex items-center space-x-4 mt-2 text-sm text-slate-500">
                              <span>{case_.court || 'Federal Court'}</span>
                              <span>{case_.jurisdiction || 'Federal'}</span>
                              <span>{case_.date_decided ? new Date(case_.date_decided).getFullYear() : 'Recent'}</span>
                            </div>
                          </div>
                          
                          <div className="text-right">
                            <div className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium text-white ${getSimilarityColor(similarityScore)}`}>
                              {getSimilarityLabel(similarityScore)}
                            </div>
                            <div className="text-xs text-slate-500 mt-1">
                              {Math.round(similarityScore * 100)}% match
                            </div>
                          </div>
                        </div>

                        {/* Similarity Metrics */}
                        <div className="grid grid-cols-3 gap-4 py-3 border-t border-b border-slate-200">
                          <div className="text-center">
                            <div className="text-lg font-semibold text-slate-900">
                              {Math.round((similarCase.text_similarity || 0) * 100)}%
                            </div>
                            <div className="text-xs text-slate-500">Text Similarity</div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-semibold text-slate-900">
                              {Math.round((similarCase.issue_overlap || 0) * 100)}%
                            </div>
                            <div className="text-xs text-slate-500">Issue Overlap</div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-semibold text-slate-900">
                              {formatPrecedentStrength(similarCase.precedent_strength || 0)}
                            </div>
                            <div className="text-xs text-slate-500">Precedent Value</div>
                          </div>
                        </div>

                        {/* Case Summary */}
                        <div>
                          <p className="text-sm text-slate-600 leading-relaxed">
                            {case_.case_summary || case_.case_text?.substring(0, 300) + '...' || 'Case summary not available'}
                          </p>
                        </div>

                        {/* Legal Topics */}
                        {case_.legal_topics && case_.legal_topics.length > 0 && (
                          <div className="flex flex-wrap gap-2">
                            {case_.legal_topics.slice(0, 4).map((topic: string, topicIndex: number) => (
                              <span 
                                key={topicIndex}
                                className="bg-slate-100 text-slate-700 px-2 py-1 rounded text-xs font-medium"
                              >
                                {topic}
                              </span>
                            ))}
                          </div>
                        )}

                        {/* Actions */}
                        <div className="flex items-center justify-between pt-3 border-t border-slate-200">
                          <div className="text-xs text-slate-500">
                            Case ID: {case_.case_id || 'N/A'}
                          </div>
                          <div className="flex items-center space-x-3">
                            <button className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center">
                              <Target className="h-4 w-4 mr-1" />
                              Analyze Impact
                            </button>
                            <button className="text-slate-600 hover:text-slate-700 text-sm font-medium flex items-center">
                              <ExternalLink className="h-4 w-4 mr-1" />
                              View Full Case
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </>
          ) : (
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-12 text-center">
              {isSearching ? (
                <>
                  <Loader className="animate-spin h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-slate-500 mb-2">Searching Legal Database...</h3>
                  <p className="text-slate-400">
                    Analyzing case similarity using AI pattern matching
                  </p>
                </>
              ) : (
                <>
                  <Scale className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-slate-500 mb-2">No Similar Cases Found</h3>
                  <p className="text-slate-400">
                    Enter case details above to find similar precedents and legal cases
                  </p>
                </>
              )}
            </div>
          )}
          
          {/* Search Information */}
          <div className="bg-blue-50 rounded-lg border border-blue-200 p-6">
            <div className="flex items-start">
              <Target className="h-6 w-6 text-blue-600 mt-1" />
              <div className="ml-3">
                <h3 className="text-sm font-medium text-blue-900">AI-Powered Case Matching</h3>
                <p className="mt-1 text-sm text-blue-700">
                  Our similarity engine uses advanced text analysis and legal concept matching to find 
                  relevant precedents. The system analyzes case facts, legal issues, jurisdiction, and 
                  judicial outcomes to identify cases with strategic relevance to your situation.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SimilarCaseFinder
