import React, { useState } from 'react'
import { useLegalOracle } from '../contexts/LegalOracleContext'
import { Gavel, Search, TrendingUp, BarChart3, User, Brain, CheckCircle } from 'lucide-react'
import { toast } from 'sonner'

const JudgeBehaviorAnalysis: React.FC = () => {
  const { judges, loading, analysisResults, analyzeJudge, searchJudges } = useLegalOracle()
  const [selectedJudge, setSelectedJudge] = useState<any>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [caseTypeFilter, setCaseTypeFilter] = useState('civil')
  const [analyzing, setAnalyzing] = useState(false)

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      setSearchResults([])
      return
    }

    try {
      const results = await searchJudges(searchQuery)
      setSearchResults(results)
    } catch (error) {
      console.error('Judge search failed:', error)
    }
  }

  const handleAnalyzeJudge = async () => {
    if (!selectedJudge) {
      toast.error('Please select a judge for analysis')
      return
    }

    setAnalyzing(true)
    try {
      await analyzeJudge(selectedJudge, caseTypeFilter)
      toast.success('Judge behavior analysis completed')
    } catch (error) {
      console.error('Judge analysis failed:', error)
    } finally {
      setAnalyzing(false)
    }
  }

  const displayJudges = searchResults.length > 0 ? searchResults : judges
  const analysis = analysisResults.judge_analysis

  const getDecisionRateColor = (rate: number) => {
    if (rate >= 0.7) return 'text-green-600'
    if (rate >= 0.4) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getDecisionRateBackground = (rate: number) => {
    if (rate >= 0.7) return 'bg-green-100'
    if (rate >= 0.4) return 'bg-yellow-100'
    return 'bg-red-100'
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900 flex items-center">
          <Gavel className="h-8 w-8 text-blue-600 mr-3" />
          Judge Behavior Analysis
        </h1>
        <p className="mt-2 text-lg text-slate-600">
          Analyze judicial patterns and predict decision-making tendencies using AI
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Selection Section */}
        <div className="space-y-6">
          {/* Judge Search */}
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-medium text-slate-900 mb-4">Find Judge</h3>
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value)
                    handleSearch()
                  }}
                  placeholder="Search judges by name or court..."
                  className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Judge List */}
          <div className="bg-white rounded-lg shadow-sm border border-slate-200">
            <div className="p-4 border-b border-slate-200">
              <h3 className="text-lg font-medium text-slate-900">
                Available Judges ({displayJudges.length})
              </h3>
            </div>
            <div className="max-h-96 overflow-y-auto">
              {displayJudges.map((judge, index) => (
                <div 
                  key={judge.id || index}
                  className={`p-4 border-b border-slate-100 cursor-pointer transition-colors ${
                    selectedJudge?.id === judge.id ? 'bg-blue-50 border-blue-200' : 'hover:bg-slate-50'
                  }`}
                  onClick={() => setSelectedJudge(judge)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium text-slate-900">{judge.judge_name}</h4>
                      <p className="text-sm text-slate-600">{judge.court}</p>
                      <div className="flex items-center space-x-4 mt-2 text-xs text-slate-500">
                        <span>{judge.cases_decided} cases decided</span>
                        <span>{Math.round((judge.reversal_rate || 0) * 100)}% reversal rate</span>
                        <span className="capitalize">{judge.judicial_philosophy}</span>
                      </div>
                    </div>
                    {selectedJudge?.id === judge.id && (
                      <CheckCircle className="h-5 w-5 text-blue-600" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Analysis Controls */}
          {selectedJudge && (
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
              <h3 className="text-lg font-medium text-slate-900 mb-4">Analysis Settings</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Case Type for Analysis
                  </label>
                  <select
                    value={caseTypeFilter}
                    onChange={(e) => setCaseTypeFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="civil">Civil Cases</option>
                    <option value="criminal">Criminal Cases</option>
                    <option value="regulatory">Regulatory Cases</option>
                    <option value="corporate">Corporate Cases</option>
                    <option value="ip">Intellectual Property</option>
                    <option value="employment">Employment Cases</option>
                  </select>
                </div>
                
                <button
                  onClick={handleAnalyzeJudge}
                  disabled={analyzing}
                  className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 disabled:bg-slate-400 flex items-center justify-center"
                >
                  {analyzing ? (
                    <>
                      <Brain className="animate-pulse h-5 w-5 mr-2" />
                      Analyzing Patterns...
                    </>
                  ) : (
                    <>
                      <BarChart3 className="h-5 w-5 mr-2" />
                      Analyze Judge Behavior
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Results Section */}
        <div className="space-y-6">
          {/* Selected Judge Profile */}
          {selectedJudge && (
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
              <div className="flex items-center mb-4">
                <User className="h-6 w-6 text-slate-600 mr-2" />
                <h3 className="text-lg font-medium text-slate-900">Judge Profile</h3>
              </div>
              
              <div className="space-y-3">
                <div>
                  <span className="text-sm font-medium text-slate-500">Name:</span>
                  <span className="ml-2 text-slate-900">{selectedJudge.judge_name}</span>
                </div>
                <div>
                  <span className="text-sm font-medium text-slate-500">Court:</span>
                  <span className="ml-2 text-slate-900">{selectedJudge.court}</span>
                </div>
                <div>
                  <span className="text-sm font-medium text-slate-500">Jurisdiction:</span>
                  <span className="ml-2 text-slate-900">{selectedJudge.jurisdiction}</span>
                </div>
                <div>
                  <span className="text-sm font-medium text-slate-500">Judicial Philosophy:</span>
                  <span className="ml-2 capitalize text-slate-900">{selectedJudge.judicial_philosophy}</span>
                </div>
                <div>
                  <span className="text-sm font-medium text-slate-500">Political Leanings:</span>
                  <span className="ml-2 capitalize text-slate-900">{selectedJudge.political_leanings}</span>
                </div>
                
                {/* Key Metrics */}
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div className="bg-slate-50 p-3 rounded-lg">
                    <div className="text-2xl font-bold text-slate-900">{selectedJudge.cases_decided}</div>
                    <div className="text-xs text-slate-500">Cases Decided</div>
                  </div>
                  <div className={`p-3 rounded-lg ${getDecisionRateBackground(selectedJudge.precedent_adherence_score || 0)}`}>
                    <div className={`text-2xl font-bold ${getDecisionRateColor(selectedJudge.precedent_adherence_score || 0)}`}>
                      {Math.round((selectedJudge.precedent_adherence_score || 0) * 100)}%
                    </div>
                    <div className="text-xs text-slate-500">Precedent Adherence</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Analysis Results */}
          {analysis ? (
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
              <div className="flex items-center mb-4">
                <Brain className="h-6 w-6 text-green-600 mr-2" />
                <h3 className="text-lg font-medium text-slate-900">AI Behavior Analysis</h3>
              </div>
              
              <div className="space-y-4">
                {/* Behavioral Tendencies */}
                <div>
                  <h4 className="text-sm font-medium text-slate-700 mb-2">Behavioral Tendencies</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-slate-600">
                    {analysis.behavioral_tendencies?.map((tendency: string, index: number) => (
                      <li key={index}>{tendency}</li>
                    ))}
                  </ul>
                </div>
                
                {/* Prediction for Case Type */}
                <div>
                  <h4 className="text-sm font-medium text-slate-700 mb-2">
                    Prediction for {caseTypeFilter.charAt(0).toUpperCase() + caseTypeFilter.slice(1)} Cases
                  </h4>
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <p className="text-sm text-blue-800">{analysis.prediction_for_case_type}</p>
                  </div>
                </div>
                
                {/* Confidence Score */}
                <div>
                  <h4 className="text-sm font-medium text-slate-700 mb-2">Analysis Confidence</h4>
                  <div className="flex items-center">
                    <div className="flex-1 bg-slate-200 rounded-full h-2">
                      <div 
                        className="bg-green-600 h-2 rounded-full"
                        style={{ width: `${(analysis.confidence_score || 0) * 100}%` }}
                      />
                    </div>
                    <span className="ml-2 text-sm font-medium text-slate-900">
                      {Math.round((analysis.confidence_score || 0) * 100)}%
                    </span>
                  </div>
                </div>
                
                {/* Precedent Adherence */}
                <div>
                  <h4 className="text-sm font-medium text-slate-700 mb-2">Precedent Adherence Score</h4>
                  <div className="flex items-center">
                    <div className="flex-1 bg-slate-200 rounded-full h-2">
                      <div 
                        className="bg-purple-600 h-2 rounded-full"
                        style={{ width: `${(analysis.precedent_adherence || 0) * 100}%` }}
                      />
                    </div>
                    <span className="ml-2 text-sm font-medium text-slate-900">
                      {Math.round((analysis.precedent_adherence || 0) * 100)}%
                    </span>
                  </div>
                </div>
                
                {/* Sentencing Patterns */}
                <div>
                  <h4 className="text-sm font-medium text-slate-700 mb-2">Sentencing Patterns</h4>
                  <div className="bg-slate-50 p-3 rounded-lg">
                    <p className="text-sm text-slate-700">{analysis.sentencing_patterns}</p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 rounded-lg border border-slate-200 p-8 text-center">
              <TrendingUp className="h-12 w-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-500 mb-2">No Analysis Yet</h3>
              <p className="text-slate-400">
                Select a judge and click "Analyze Judge Behavior" to see behavioral patterns and predictions
              </p>
            </div>
          )}
          
          {/* AI Information */}
          <div className="bg-purple-50 rounded-lg border border-purple-200 p-6">
            <div className="flex items-start">
              <Brain className="h-6 w-6 text-purple-600 mt-1" />
              <div className="ml-3">
                <h3 className="text-sm font-medium text-purple-900">Behavioral Pattern Analysis</h3>
                <p className="mt-1 text-sm text-purple-700">
                  This analysis uses AI to identify patterns in judicial decision-making based on historical 
                  case data, judicial philosophy, and precedent adherence. Results help predict likely 
                  judicial behavior in specific case types.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default JudgeBehaviorAnalysis
