import React from 'react'
import { Scale, Brain, TrendingUp, Users } from 'lucide-react'

const Header: React.FC = () => {
  return (
    <header className="bg-slate-900 text-white shadow-xl border-b border-slate-700">
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-3">
            <div className="flex items-center justify-center w-10 h-10 bg-blue-600 rounded-lg">
              <Scale className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">
                Legal Oracle
              </h1>
              <p className="text-xs text-slate-300">
                AI-Powered Legal Strategic Intelligence Platform
              </p>
            </div>
          </div>
          
          {/* Platform Features */}
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2 text-slate-300">
              <Brain className="h-4 w-4" />
              <span className="text-sm font-medium">HuggingFace AI Integration</span>
            </div>
            <div className="flex items-center space-x-2 text-slate-300">
              <TrendingUp className="h-4 w-4" />
              <span className="text-sm font-medium">Real Legal Data Analysis</span>
            </div>
            <div className="flex items-center space-x-2 text-slate-300">
              <Users className="h-4 w-4" />
              <span className="text-sm font-medium">Game Theory Analytics</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header
